<!DOCTYPE HTML>
<!--
	Dimension by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>暂未上线</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
					<header id="header">
						<div class="logo">
							<span class="icon fa-diamond"></span>
						</div>
						<div class="content">
							<div class="inner">
								<h1>预计1月8日前完成</h1>
								<p>
								宝贝，对不起哦，此功能暂未上线。不过，放心，一切都在我的掌控之中，不会拖很久！</p>
							</div>
						</div>
						<nav>
							<ul>
								<li><a href="<?php $openid=$_GET['openid'];$herf= 'function.php?openid='.$openid;echo $herf; ?>">教务首页</a></li>
								<li><a href="<?php $openid=$_GET['openid'];$herf= 'Showscore.php?openid='.$openid;echo $herf; ?>">微信成绩</a></li>
								<li><a href="<?php $openid=$_GET['openid'];$herf= 'Showtable.php?openid='.$openid;echo $herf; ?>">微信课表</a></li>
								<li><a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a></li>
								<!--<li><a href="#elements">Elements</a></li>-->
							</ul>
						</nav>
					</header>

				<!-- Main -->
				
	
				<!-- Footer -->
					<footer id="footer">
						<p class="copyright">&copy; THANKS: <a href="#">404.LIFE</a>.</p>
					</footer>

			</div>

		<!-- BG -->
			<div id="bg"></div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
	
	
	<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?9aaf8e338f227693c30fb3995a54673b";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>

	
	
</html>
