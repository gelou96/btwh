<?php
function nine($openid){
    $openid = $openid;
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        echo 'The connection is false,please test again or wait a time! The best way to solve the problem is add my wechat——>>18235273200（阁楼） ';
    }else{
        $mysqli->query("set names utf8" );
        $result = $mysqli->query ("SELECT nine FROM score WHERE openid='$openid'");
        while ( list ( $nine ) = $result->fetch_row() ){
            $nine1 = $nine;
        }
        $result->close (); // 【不同传媒】
        $mysqli->close ();
    }
    $td_array_nine = json_decode($nine1, true);
    if($nine1=='null'){
    	echo '暂无这学期成绩';
    }else{
        for($i=6;;$i++){
			if($td_array_nine[$i][2]== ''){
				break;
			}	
		}
        $no = 0;
        $jd_xf = 0;
	    $xf = 0;
	    $cj = 0;
        for($a = 6;$a<=$i-1;$a++){
			echo '<tr>';
			echo '<td>';
			print_r($td_array_nine[$a][2]);//科目名称
			echo '</td>';
			echo '<td>';
			print_r($td_array_nine[$a][4]);//学分
			echo '</td>';
			echo '<td>';
			print_r($td_array_nine[$a][5]);//课程属性
			echo '</td>';
			echo '<td>';
			print_r($td_array_nine[$a][6]);//分数
			echo '</td>';
			echo '</tr>';
		}
    }
}
?>