<?php
function nameshow($openid){
    $openid = $openid;
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'The connection is false,please test again or wait a time!';
    }else{
        $openid = $openid;
        $mysqli->query("set names utf8" );
        $result = $mysqli->query ("SELECT name FROM xueji WHERE openid='$openid'");
        while ( list ( $name ) = $result->fetch_row() ){
            $xm = $name;
        }
        $result->close (); // 关闭结果集
        $mysqli->close ();
    }
    $xm = preg_replace("/;/", "", $xm);
    $xm = preg_replace("'([\r\n])[\s]+'", "", $xm);
	return $xm;
}
?>