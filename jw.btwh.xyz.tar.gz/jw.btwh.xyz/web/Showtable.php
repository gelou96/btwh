<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <base href="<%=basePath%>">
        <meta charset="UTF-8">
        <title>不同文化|课表查询</title>
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
        <meta content="yes" name="apple-mobile-web-app-capable">
        <meta content="black" name="apple-mobile-web-app-status-bar-style">
        <meta content="telephone=no" name="format-detection">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <!-- 如果使用双核浏览器，强制使用webkit来进行页面渲染 -->
        <meta name="renderer" content="webkit" />
        <!-- 网站描述 
        <meta name="keywords" content="" /> 
        <meta name="description" content="" />
        -->
        <link rel="stylesheet" href="css/timetable.css">
        <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
        <script type="text/javascript" src="js/jquery.touchSwipe.min.js"></script>
        <script type="text/javascript" src="js/timetable.js"></script>
       
    </head>
    
    <script>
        function onBridgeReady() {
            WeixinJSBridge.call('hideOptionMenu');
        }
 
        if (typeof WeixinJSBridge == "undefined") {
            if (document.addEventListener) {
                document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
            } else if (document.attachEvent) {
                document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
                document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
            }
        } else {
            onBridgeReady();
        }
    </script>
    
    <script type="text/javascript">
        // 对浏览器的UserAgent进行正则匹配，不含有微信独有标识的则为其他浏览器
        var useragent = navigator.userAgent;
        if (useragent.match(/MicroMessenger/i) != 'MicroMessenger') {
            // 这里警告框会阻塞当前页面继续加载
            alert('同学你好，请从微信公众号【不同传媒】进入哦！如有其它问题请咨询微信：18235273200');
            // 以下代码是用javascript强行关闭当前页面
            var opened = window.open('http://jw.btwh.xyz', '_self');
            opened.opener = null;
            opened.close();
        }
    </script>

    
    <body>
        <table>
            <tr>
                <th></th>
                <th>周一</th>
                <th>周二</th>
                <th>周三</th>
                <th>周四</th>
                <th>周五</th>
                <th>周六</th>
                <th>周日</th>
            </tr>
            
            <?php $openid = $_GET['openid'];include("get_table.php");?>
            
            <!--第一节，第二节-->
            <tr>
                <th rowspan="1">1</th>
                
                <?php $a = kb($openid,0,1);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#13CA9A" rowspan="2">';echo $a;}?>
                </td>
                <?php $a = kb($openid,1,1);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#BA8ADE" rowspan="2">';echo $a;}	
				?>
                </td>
                <?php $a = kb($openid,2,1);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#FD8C40" rowspan="2">';echo $a;}?>
                </td>
                <?php $a = kb($openid,3,1);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#C9C9C9" rowspan="2">';echo $a;}?>
                </td>
                <?php $a = kb($openid,4,1);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#3DB5E7"rowspan="2">'; echo $a;}?>
                </td>
                <?php $a = kb($openid,5,1);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#FF828A" rowspan="2">';echo $a;}?>
                </td>
                <?php $a = kb($openid,6,1);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#EA69A2" rowspan="2">';echo $a;}?>
                </td>  
            </tr>
            <tr>
            	<th rowspan="1">2</th>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            </tr>

            <!--第三节，第四节-->
            <tr>
                <th rowspan="1">3</th>
                
                <?php $a = kb($openid,0,2);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#FFB81E" rowspan="2">';echo $a;   
				}?>
                </td>
                <?php $a = kb($openid,1,2);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#FF828A" rowspan="2">';echo $a;
				}?>
                </td>
                <?php $a = kb($openid,2,2);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#EA69A2" rowspan="2">';echo $a;}?>
                </td>
                <?php $a = kb($openid,3,2);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#FE3E65" rowspan="2">';echo $a;}?>
                </td>
                <?php $a = kb($openid,4,2);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#7E57C6" rowspan="2">';echo $a;}?>
                </td>
                <?php $a = kb($openid,5,2);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#B3D465" rowspan="2">';echo $a;}?>
                </td>
                <?php $a = kb($openid,6,2);if($a == ''){echo '<td >';}else{echo '<td bgcolor="#F29C77" rowspan="2">';echo $a;}?>
                </td> 
            </tr>
			<tr>
            	<th rowspan="1">4</th>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            </tr>
            
            <!--第五节，第六节-->
            <tr>
                <th rowspan="1">5</th>
                
                <?php $a = kb($openid,0,4); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#B3D465" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,1,4); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#F29C77" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,2,4); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#13CA9A" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,3,4); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#FFB81E" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,4,4); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#3DB5E7" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,5,4); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#7E57C6" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,6,4); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#B3D465" rowspan="2">'; echo $a;} ?>
                </td>

            </tr> 
			<tr>
            	<th rowspan="1">6</th>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            </tr>

            <!--第七节，第八节-->
           <tr>
                <th rowspan="1">7</th>
                
                <?php $a = kb($openid,0,5); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#7E57C6" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,1,5); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#3DB5E7" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,2,5); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#B3D465" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,3,5); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#BA8ADE" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,4,5); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#FF828A" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,5,5); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#FE3E65" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,6,5); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#13CA9A" rowspan="2">'; echo $a;} ?>
                </td>

            </tr> 
            <tr>
            	<th rowspan="1">8</th>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            </tr>

            <!--第九节，第十节-->  
            
            <tr>
                <th rowspan="1">9</th>
                
                <?php $a = kb($openid,0,7); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#FD8C40" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,1,7); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#EA69A2" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,2,7); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#13CA9A" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,3,7); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#C9C9C9" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,4,7); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#FE3E65" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,5,7); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#3DB5E7" rowspan="2">'; echo $a;} ?>
                </td>
                <?php $a = kb($openid,6,7); if($a == ''){ echo '<td >'; }else{ echo '<td bgcolor="#BA8ADE" rowspan="2">'; echo $a;} ?>
                </td>

            </tr> 
			<tr>
            	<th rowspan="1">10</th>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            	<td></td>
            </tr>
    
        </table>
        <div class="append">
        </div>
        <!-- <!-- 提示框 -->
        <!--<div class="weui_toptips weui_warn js_tooltips"></div>-->
        <nav>
            <div><a href="<?php $openid=$_GET['openid'];$herf= 'function.php?openid='.$openid;echo $herf; ?>"><img src="img/zy.png"><br/>主界面</a></div>
            <div><a class="on"><img src="img/timetable.png"><br/>课表</a></div>
            <div><a href="<?php $openid=$_GET['openid'];$herf= 'Showscore.php?openid='.$openid;echo $herf; ?>"><img src="img/grade.png"><br/>成绩</a></div>
            <div><a href="<?php $openid=$_GET['openid'];$herf= 'update_table.php?openid='.$openid;echo $herf; ?>"><img src="img/kb_up.png"><br/>更新课表</a></div>
      
        </nav>
    </body>
    <script>
        var _hmt = _hmt || [];
        (function() {
            var hm = document.createElement("script");
            hm.src = "https://hm.baidu.com/hm.js?4d27a28208491d26bc415ecf9c988085";
            var s = document.getElementsByTagName("script")[0]; 
            s.parentNode.insertBefore(hm, s);
        })();
</script>
</html>