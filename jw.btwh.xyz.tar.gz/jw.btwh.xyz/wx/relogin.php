<?php
//我没有做重新绑定界面，看反馈吧！
//需要做，我再做！
//时间：2020.01.06
function relogin($openid){
    $open = $openid;
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if (mysqli_connect_errno ()){
        $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
    }else{
        $open = $open;
        $mysqli->query("set names utf8" ); // 设置结果的字符集
        $result = $mysqli->query ( "SELECT openid FROM bindmessage WHERE openid='$open'" );
        if ( !list ( $openid ) = $result->fetch_row() ){
            $message =  '<a href="http://jw.btwh.xyz/web/login.php?openid='.$open.'">点我重新绑定教务|新系统|望理解</a>';
            $result->close (); 
            $mysqli->close ();
        }else{
            $message = '<a href="http://jw.btwh.xyz/web/update.php?openid='.$open.'">点我重新绑定教务</a>';
        }
    }
    $result->close (); 
    $mysqli->close ();
    $relogin = $message;
    return $relogin;
}
?>