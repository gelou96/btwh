<?php
function score($openid){
    $openid = $openid;
    //链接数据库
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if (mysqli_connect_errno ()){
        $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
    }else{
        $open = $openid;	
        $mysqli->query("set names utf8" ); // 设置结果的字符集
        $result = $mysqli->query ( "SELECT openid FROM score WHERE openid='$open'" );
        if ( !list ( $openid ) = $result->fetch_row() ){
            $message =  '<a href="http://jw.btwh.xyz/web/login.php?openid='.$open.'">点我重新绑定教务|新系统|望理解</a>';
            $result->close (); 
            $mysqli->close ();
        }else{
            $openid = $open;
            $mysqli->query("set names utf8" ); // 设置结果的字符集
            $result = $mysqli->query ("SELECT xh FROM bindmessage WHERE openid='$openid'");
            while ( list ( $xh ) = $result->fetch_row() ) { // 从结果集中遍历每条数据
                $zh = $xh;
            }
            $result->close (); // 关闭结果集
            $mysqli->close ();
            $zh = preg_replace("'([\r\n])[\s]+'", "", $zh);
            
            //重新连接数据库
            $host = 'localhost:3306';
            $username = 'btwh';
            $password = 'btwh';
            $dbname = 'btwh';
            $mysqli = new mysqli($host,$username,$password,$dbname);
            
            if($zh>150000000000&&$zh<160000000000){
                if (mysqli_connect_errno ()){
                    $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
                }else{
                    $openid = $openid;
                    $mysqli->query("set names utf8" ); // 设置结果的字符集
                    $result = $mysqli->query ("SELECT eight FROM score WHERE openid='$openid'");
                    while ( list ( $eight ) = $result->fetch_row() ) { // 从结果集中遍历每条数据
                        $cj = $eight;    
                    }
                    $result->close (); // 关闭结果集
                    $mysqli->close ();
                }
            }else if($zh>160000000000&&$zh<170000000000){
                if (mysqli_connect_errno ()){
                    $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
                }else{
                    $openid = $openid;
                    $mysqli->query("set names utf8" ); // 设置结果的字符集
                    $result = $mysqli->query ("SELECT six FROM score WHERE openid='$openid'");
                    while ( list ( $six ) = $result->fetch_row() ) { // 从结果集中遍历每条数据
                        $cj = $six;    
                    }
                    $result->close (); // 关闭结果集
                    $mysqli->close ();
                }
            }else if($zh>170000000000&&$zh<180000000000){
                if (mysqli_connect_errno ()){
                    $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
                }else{
                    $openid = $openid;
                    $mysqli->query("set names utf8" ); // 设置结果的字符集
                    $result = $mysqli->query ("SELECT four FROM score WHERE openid='$openid'");
                    while ( list ( $four ) = $result->fetch_row() ) { // 从结果集中遍历每条数据
                        $cj = $four;    
                    }
                    $result->close (); // 关闭结果集
                    $mysqli->close ();
                }
            }else if($zh>180000000000&&$zh<190000000000){
                if (mysqli_connect_errno ()){
                    $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
                }else{
                    $openid = $openid;
                    $mysqli->query("set names utf8" ); // 设置结果的字符集
                    $result = $mysqli->query ("SELECT two FROM score WHERE openid='$openid'");
                    while ( list ( $two ) = $result->fetch_row() ) { // 从结果集中遍历每条数据
                        $cj = $two;    
                    }
                    $result->close (); // 关闭结果集
                    $mysqli->close ();
                }
            }else if($zh>190000000000&&$zh<200000000000){
                if (mysqli_connect_errno ()){
                    $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
                }else{
                    $openid = $openid;
                    $mysqli->query("set names utf8" ); // 设置结果的字符集
                    $result = $mysqli->query ("SELECT zero FROM score WHERE openid='$openid'");
                    while ( list ( $zero ) = $result->fetch_row() ) { // 从结果集中遍历每条数据
                        $cj = $zero;    
                    }
                    $result->close (); // 关闭结果集
                    $mysqli->close ();
                }
            }
            $cj = $cj;
            $message = $message;
            $td_array = json_decode($cj, true);
            if($cj=='null'){
                $message = "小主，暂无本学期成绩哦，请回复“更新”试试！";
            }else{
                $br = "\n";
                $fy = "   ";

                //计算两个时间差的方法 
                $startdate="2019-09-02 00:00:00";
                $enddate=date("y-m-d h:i:s");
                $date=floor((strtotime($enddate)-strtotime($startdate))/86400);
                echo $date."天<br>";
                $b = $date%7;
                $a = $date-$b;
                $a = $a/7+1;

                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://jw.btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2018-2019学年春(第二学期)';
                
                $message =$td_array[6][2].$fy.$td_array[6][6].$br.$td_array[7][2].$fy.$td_array[7][6].$br.$td_array[8][2].$fy.$td_array[8][6].$br.$td_array[9][2].$fy.$td_array[9][6].$br.$td_array[10][2].$fy.$td_array[10][6].$br.$td_array[11][2].$fy.$td_array[11][6].$br.$td_array[12][2].$fy.$td_array[12][6].$br.$td_array[13][2].$fy.$td_array[13][6].$br.$td_array[14][2].$fy.$td_array[14][6].$br.$td_array[15][2].$fy.$td_array[15][6].$br.$td_array[16][2].$fy.$td_array[16][6].$br.$td_array[17][2].$fy.$td_array[17][6].$br.$td_array[18][2].$fy.$td_array[18][6].$br.$td_array[19][2].$fy.$td_array[19][6].$br.$td_array[20][2].$fy.$td_array[20][6].$br.$td_array[21][2].$fy.$td_array[21][6].$br.$td_array[22][2].$fy.$td_array[22][6].$br.$td_array[23][2].$fy.$td_array[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;	
                }
            $message = $message;
            }
        $message = $message;
    }
    $message = $message;
    return $message;
}
        
        
        
        
        
        
        
        
        
        
        /*
        $openid = $openid;
        $mysqli->query("set names utf8" ); // 设置结果的字符集
        $result = $mysqli->query ("SELECT xh FROM bindmessage WHERE openid='$openid'");
        while ( list ( $xh ) = $result->fetch_row() ) { // 从结果集中遍历每条数据
            $zh = $xh;
        }
        $result->close (); // 关闭结果集
        $mysqli->close ();
        $zh = preg_replace("'([\r\n])[\s]+'", "", $zh);
        
        $openid = $openid;
        
        
        
        if($zh>140000000000&&$zh<150000000000){
            //链接数据库
            $host = 'localhost:3306';
            $username = 'btwh';
            $password = 'btwh';
            $dbname = 'btwh';
            $mysqli = new mysqli($host,$username,$password,$dbname);
            if (mysqli_connect_errno ()){
                $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
            }else{
                $openid = $openid;
                
            }
            
        }
        */
        
        
        
        
        
        
        
        
        
        
        
        

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*
    $open = $openid;
    //链接数据库
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if (mysqli_connect_errno ()){
        $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
    }else{
        $mysqli->query("set names utf8" ); // 设置结果的字符集
        $result = $mysqli->query ( "SELECT openid FROM bindmessage WHERE openid='$open'" );
        if ( !list ( $openid ) = $result->fetch_row() ){
            $message =  '<a href="http://jw.btwh.xyz/web/login.php?openid='.$open.'">点我重新绑定教务|新系统|望理解</a>';
        }else{
            $openid = $open;
            //既然已经绑定了，那么就要在数据库读取数据
            //必须判断大几（尤其是医学院的大五）
            $mysqli->query("set names utf8" );
            $result = $mysqli->query ("SELECT zero,one,two,three,four,five,six,seven,eight FROM score WHERE openid='$openid'");
             while ( list ( $zero,$one,$two,$three,$four,$five,$six,$seven,$eight,$nine ) = $result->fetch_row() ){
            $zero1 = $zero;
            $one1 = $one;
            $two1 = $two;
            $three1 = $three;
            $four1 = $four;
            $five1 = $five;
            $six1 = $six;
            $seven1 = $seven;
            $eight1 = $eight;
            $nine1 = $nine;
            $stmt->execute();
            $stmt->close();
            $mysqli->close();
        }
            /*
            //如果大一第二学期成绩是空的则输出大一第一学期的成绩
            if($one1=='null'){
                $td_array_zero = json_decode($zero1, true);
                for($i=6;;$i++){
                    if($td_array_zero[$i][2]== ''){
                    break;
                    }	
                }
                $no = 0;
                $jd_xf = 0;
                $xf = 0;
                $cj = 0;
                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://http://btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2019-2020学年秋(第一学期)';
                $message =$td_array_zero[6][2].$fy.$td_array_zero[6][6].$br.$td_array_zero[7][2].$fy.$td_array_zero[7][6].$br.$td_array_zero[8][2].$fy.$td_array_zero[8][6].$br.$td_array_zero[9][2].$fy.$td_array_zero[9][6].$br.$td_array_zero[10][2].$fy.$td_array_zero[10][6].$br.$td_array_zero[11][2].$fy.$td_array_zero[11][6].$br.$td_array_zero[12][2].$fy.$td_array_zero[12][6].$br.$td_array_zero[13][2].$fy.$td_array_zero[13][6].$br.$td_array_zero[14][2].$fy.$td_array_zero[14][6].$br.$td_array_zero[15][2].$fy.$td_array_zero[15][6].$br.$td_array_zero[16][2].$fy.$td_array_zero[16][6].$br.$td_array_zero[17][2].$fy.$td_array_zero[17][6].$br.$td_array_zero[18][2].$fy.$td_array_zero[18][6].$br.$td_array_zero[19][2].$fy.$td_array_zero[19][6].$br.$td_array_zero[20][2].$fy.$td_array_zero[20][6].$br.$td_array_zero[21][2].$fy.$td_array_zero[21][6].$br.$td_array_zero[22][2].$fy.$td_array_zero[22][6].$br.$td_array_zero[23][2].$fy.$td_array_zero[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;$message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;		    
            
                //如果大二第一学期成绩是空的则输出大一第二学期的成绩
            }else if($two1=='null'){
                $td_array_one = json_decode($one1, true);
                for($i=6;;$i++){
                    if($td_array_one[$i][2]== ''){
                    break;
                    }	
                }
                $no = 0;
                $jd_xf = 0;
                $xf = 0;
                $cj = 0;
                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2019-2020学年秋(第一学期)';
                $message =$td_array_one[6][2].$fy.$td_array_one[6][6].$br.$td_array_one[7][2].$fy.$td_array_one[7][6].$br.$td_array_one[8][2].$fy.$td_array_one[8][6].$br.$td_array_one[9][2].$fy.$td_array_one[9][6].$br.$td_array_one[10][2].$fy.$td_array_one[10][6].$br.$td_array_one[11][2].$fy.$td_array_one[11][6].$br.$td_array_one[12][2].$fy.$td_array_one[12][6].$br.$td_array_one[13][2].$fy.$td_array_one[13][6].$br.$td_array_one[14][2].$fy.$td_array_one[14][6].$br.$td_array_one[15][2].$fy.$td_array_one[15][6].$br.$td_array_one[16][2].$fy.$td_array_one[16][6].$br.$td_array_one[17][2].$fy.$td_array_one[17][6].$br.$td_array_one[18][2].$fy.$td_array_one[18][6].$br.$td_array_one[19][2].$fy.$td_array_one[19][6].$br.$td_array_one[20][2].$fy.$td_array_one[20][6].$br.$td_array_one[21][2].$fy.$td_array_one[21][6].$br.$td_array_one[22][2].$fy.$td_array_one[22][6].$br.$td_array_one[23][2].$fy.$td_array_one[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;$message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;
                
                //如果大二第二学期成绩是空的则输出大二第一学期的成绩
            }else if($three1=='null'){
                $td_array_two = json_decode($two1, true);
                for($i=6;;$i++){
                    if($td_array_two[$i][2]== ''){
                    break;
                    }	
                }
                $no = 0;
                $jd_xf = 0;
                $xf = 0;
                $cj = 0;
                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2019-2020学年秋(第一学期)';
                $message =$td_array_two[6][2].$fy.$td_array_two[6][6].$br.$td_array_two[7][2].$fy.$td_array_two[7][6].$br.$td_array_two[8][2].$fy.$td_array_two[8][6].$br.$td_array_two[9][2].$fy.$td_array_two[9][6].$br.$td_array_two[10][2].$fy.$td_array_two[10][6].$br.$td_array_two[11][2].$fy.$td_array_two[11][6].$br.$td_array_two[12][2].$fy.$td_array_two[12][6].$br.$td_array_two[13][2].$fy.$td_array_two[13][6].$br.$td_array_two[14][2].$fy.$td_array_two[14][6].$br.$td_array_two[15][2].$fy.$td_array_two[15][6].$br.$td_array_two[16][2].$fy.$td_array_two[16][6].$br.$td_array_two[17][2].$fy.$td_array_two[17][6].$br.$td_array_two[18][2].$fy.$td_array_two[18][6].$br.$td_array_two[19][2].$fy.$td_array_two[19][6].$br.$td_array_two[20][2].$fy.$td_array_two[20][6].$br.$td_array_two[21][2].$fy.$td_array_two[21][6].$br.$td_array_two[22][2].$fy.$td_array_two[22][6].$br.$td_array_two[23][2].$fy.$td_array_two[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;$message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;
                
                //如果大三第一学期成绩是空的则输出大二第二学期的成绩
            }else if($four1=='null'){
                $td_array_three = json_decode($three1, true);
                for($i=6;;$i++){
                    if($td_array_three[$i][2]== ''){
                    break;
                    }	
                }
                $no = 0;
                $jd_xf = 0;
                $xf = 0;
                $cj = 0;
                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2019-2020学年秋(第一学期)';
                $message =$td_array_three[6][2].$fy.$td_array_three[6][6].$br.$td_array_three[7][2].$fy.$td_array_three[7][6].$br.$td_array_three[8][2].$fy.$td_array_three[8][6].$br.$td_array_three[9][2].$fy.$td_array_three[9][6].$br.$td_array_three[10][2].$fy.$td_array_three[10][6].$br.$td_array_three[11][2].$fy.$td_array_three[11][6].$br.$td_array_three[12][2].$fy.$td_array_three[12][6].$br.$td_array_three[13][2].$fy.$td_array_three[13][6].$br.$td_array_three[14][2].$fy.$td_array_three[14][6].$br.$td_array_three[15][2].$fy.$td_array_three[15][6].$br.$td_array_three[16][2].$fy.$td_array_three[16][6].$br.$td_array_three[17][2].$fy.$td_array_three[17][6].$br.$td_array_three[18][2].$fy.$td_array_three[18][6].$br.$td_array_three[19][2].$fy.$td_array_three[19][6].$br.$td_array_three[20][2].$fy.$td_array_three[20][6].$br.$td_array_three[21][2].$fy.$td_array_three[21][6].$br.$td_array_three[22][2].$fy.$td_array_three[22][6].$br.$td_array_three[23][2].$fy.$td_array_three[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;$message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;
                
                //如果大三第二学期成绩是空的则输出大三第一学期的成绩
            }else if($five1=='null'){
                $td_array_four = json_decode($four1, true);
                for($i=6;;$i++){
                    if($td_array_four[$i][2]== ''){
                    break;
                    }	
                }
                $no = 0;
                $jd_xf = 0;
                $xf = 0;
                $cj = 0;
                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2019-2020学年秋(第一学期)';
                $message =$td_array_four[6][2].$fy.$td_array_four[6][6].$br.$td_array_four[7][2].$fy.$td_array_four[7][6].$br.$td_array_four[8][2].$fy.$td_array_four[8][6].$br.$td_array_four[9][2].$fy.$td_array_four[9][6].$br.$td_array_four[10][2].$fy.$td_array_four[10][6].$br.$td_array_four[11][2].$fy.$td_array_four[11][6].$br.$td_array_four[12][2].$fy.$td_array_four[12][6].$br.$td_array_four[13][2].$fy.$td_array_four[13][6].$br.$td_array_four[14][2].$fy.$td_array_four[14][6].$br.$td_array_four[15][2].$fy.$td_array_four[15][6].$br.$td_array_four[16][2].$fy.$td_array_four[16][6].$br.$td_array_four[17][2].$fy.$td_array_four[17][6].$br.$td_array_four[18][2].$fy.$td_array_four[18][6].$br.$td_array_four[19][2].$fy.$td_array_four[19][6].$br.$td_array_four[20][2].$fy.$td_array_four[20][6].$br.$td_array_four[21][2].$fy.$td_array_four[21][6].$br.$td_array_four[22][2].$fy.$td_array_four[22][6].$br.$td_array_four[23][2].$fy.$td_array_four[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;$message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;
                
                //如果大四第一学期成绩是空的则输出大三第二学期的成绩
            }else if($six1=='null'){
                $td_array_five = json_decode($five1, true);
                for($i=6;;$i++){
                    if($td_array_five[$i][2]== ''){
                    break;
                    }	
                }
                $no = 0;
                $jd_xf = 0;
                $xf = 0;
                $cj = 0;
                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2019-2020学年秋(第一学期)';
                $message =$td_array_five[6][2].$fy.$td_array_five[6][6].$br.$td_array_five[7][2].$fy.$td_array_five[7][6].$br.$td_array_five[8][2].$fy.$td_array_five[8][6].$br.$td_array_five[9][2].$fy.$td_array_five[9][6].$br.$td_array_five[10][2].$fy.$td_array_five[10][6].$br.$td_array_five[11][2].$fy.$td_array_five[11][6].$br.$td_array_five[12][2].$fy.$td_array_five[12][6].$br.$td_array_five[13][2].$fy.$td_array_five[13][6].$br.$td_array_five[14][2].$fy.$td_array_five[14][6].$br.$td_array_five[15][2].$fy.$td_array_five[15][6].$br.$td_array_five[16][2].$fy.$td_array_five[16][6].$br.$td_array_five[17][2].$fy.$td_array_five[17][6].$br.$td_array_five[18][2].$fy.$td_array_five[18][6].$br.$td_array_five[19][2].$fy.$td_array_five[19][6].$br.$td_array_five[20][2].$fy.$td_array_five[20][6].$br.$td_array_five[21][2].$fy.$td_array_five[21][6].$br.$td_array_five[22][2].$fy.$td_array_five[22][6].$br.$td_array_five[23][2].$fy.$td_array_five[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;$message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;
                
                //如果大四第二学期成绩是空的则输出大四第一学期的成绩
            }else if($seven1=='null'){
                $td_array_six = json_decode($six1, true);
                for($i=6;;$i++){
                    if($td_array_six[$i][2]== ''){
                    break;
                    }	
                }
                $no = 0;
                $jd_xf = 0;
                $xf = 0;
                $cj = 0;
                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2019-2020学年秋(第一学期)';
                $message =$td_array_six[6][2].$fy.$td_array_six[6][6].$br.$td_array_six[7][2].$fy.$td_array_six[7][6].$br.$td_array_six[8][2].$fy.$td_array_six[8][6].$br.$td_array_six[9][2].$fy.$td_array_six[9][6].$br.$td_array_six[10][2].$fy.$td_array_six[10][6].$br.$td_array_six[11][2].$fy.$td_array_six[11][6].$br.$td_array_six[12][2].$fy.$td_array_six[12][6].$br.$td_array_six[13][2].$fy.$td_array_six[13][6].$br.$td_array_six[14][2].$fy.$td_array_six[14][6].$br.$td_array_six[15][2].$fy.$td_array_six[15][6].$br.$td_array_six[16][2].$fy.$td_array_six[16][6].$br.$td_array_six[17][2].$fy.$td_array_six[17][6].$br.$td_array_six[18][2].$fy.$td_array_six[18][6].$br.$td_array_six[19][2].$fy.$td_array_six[19][6].$br.$td_array_six[20][2].$fy.$td_array_six[20][6].$br.$td_array_six[21][2].$fy.$td_array_six[21][6].$br.$td_array_six[22][2].$fy.$td_array_six[22][6].$br.$td_array_six[23][2].$fy.$td_array_six[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;$message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;
                
                //如果大五第一学期成绩是空的则输出大四第二学期的成绩
            }else if($eight1=='null'){
                $td_array_seven = json_decode($seven1, true);
                for($i=6;;$i++){
                    if($td_array_seven[$i][2]== ''){
                    break;
                    }	
                }
                $no = 0;
                $jd_xf = 0;
                $xf = 0;
                $cj = 0;
                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2019-2020学年秋(第一学期)';
                $message =$td_array_seven[6][2].$fy.$td_array_seven[6][6].$br.$td_array_seven[7][2].$fy.$td_array_seven[7][6].$br.$td_array_seven[8][2].$fy.$td_array_seven[8][6].$br.$td_array_seven[9][2].$fy.$td_array_seven[9][6].$br.$td_array_seven[10][2].$fy.$td_array_seven[10][6].$br.$td_array_seven[11][2].$fy.$td_array_seven[11][6].$br.$td_array_seven[12][2].$fy.$td_array_seven[12][6].$br.$td_array_seven[13][2].$fy.$td_array_seven[13][6].$br.$td_array_seven[14][2].$fy.$td_array_seven[14][6].$br.$td_array_seven[15][2].$fy.$td_array_seven[15][6].$br.$td_array_seven[16][2].$fy.$td_array_seven[16][6].$br.$td_array_seven[17][2].$fy.$td_array_seven[17][6].$br.$td_array_seven[18][2].$fy.$td_array_seven[18][6].$br.$td_array_seven[19][2].$fy.$td_array_seven[19][6].$br.$td_array_seven[20][2].$fy.$td_array_seven[20][6].$br.$td_array_seven[21][2].$fy.$td_array_seven[21][6].$br.$td_array_seven[22][2].$fy.$td_array_seven[22][6].$br.$td_array_seven[23][2].$fy.$td_array_seven[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;$message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;
                
                //如果大五第二学期成绩是空的则输出大五第一学期的成绩
            }else if($nine1=='null'){
                $td_array_eight = json_decode($eight1, true);
                for($i=6;;$i++){
                    if($td_array_eight[$i][2]== ''){
                    break;
                    }	
                }
                $no = 0;
                $jd_xf = 0;
                $xf = 0;
                $cj = 0;
                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2019-2020学年秋(第一学期)';
                $message =$td_array_eight[6][2].$fy.$td_array_eight[6][6].$br.$td_array_eight[7][2].$fy.$td_array_eight[7][6].$br.$td_array_eight[8][2].$fy.$td_array_eight[8][6].$br.$td_array_eight[9][2].$fy.$td_array_eight[9][6].$br.$td_array_eight[10][2].$fy.$td_array_eight[10][6].$br.$td_array_eight[11][2].$fy.$td_array_eight[11][6].$br.$td_array_eight[12][2].$fy.$td_array_eight[12][6].$br.$td_array_eight[13][2].$fy.$td_array_eight[13][6].$br.$td_array_eight[14][2].$fy.$td_array_eight[14][6].$br.$td_array_eight[15][2].$fy.$td_array_eight[15][6].$br.$td_array_eight[16][2].$fy.$td_array_eight[16][6].$br.$td_array_eight[17][2].$fy.$td_array_eight[17][6].$br.$td_array_eight[18][2].$fy.$td_array_eight[18][6].$br.$td_array_eight[19][2].$fy.$td_array_eight[19][6].$br.$td_array_eight[20][2].$fy.$td_array_eight[20][6].$br.$td_array_eight[21][2].$fy.$td_array_eight[21][6].$br.$td_array_eight[22][2].$fy.$td_array_eight[22][6].$br.$td_array_eight[23][2].$fy.$td_array_eight[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;$message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;
                
                //如果大五第二学期成绩不是空的则输出大五第二学期的成绩
            }else if($nine1！='null'){
                $td_array_nine = json_decode($nine1, true);
                for($i=6;;$i++){
                    if($td_array_nine[$i][2]== ''){
                    break;
                    }	
                }
                $no = 0;
                $jd_xf = 0;
                $xf = 0;
                $cj = 0;
                $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."记得好好学习哦！"."/:,@f".$br."更新请回复“更新”".$br.$br;
                $table_all = '<a href="http://btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有成绩</a>';
                $table_all = $br.$table_all.$br.$br.'<a href="http://tb.dtxthq.cn">滴！看一下！</a>'.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=5PbiJ27">点我进群</a>'.' 893387628';
                $data_score = '2019-2020学年秋(第一学期)';
                $message =$td_array_nine[6][2].$fy.$td_array_nine[6][6].$br.$td_array_nine[7][2].$fy.$td_array_nine[7][6].$br.$td_array_nine[8][2].$fy.$td_array_nine[8][6].$br.$td_array_nine[9][2].$fy.$td_array_nine[9][6].$br.$td_array_nine[10][2].$fy.$td_array_nine[10][6].$br.$td_array_nine[11][2].$fy.$td_array_nine[11][6].$br.$td_array_nine[12][2].$fy.$td_array_nine[12][6].$br.$td_array_nine[13][2].$fy.$td_array_nine[13][6].$br.$td_array_nine[14][2].$fy.$td_array_nine[14][6].$br.$td_array_nine[15][2].$fy.$td_array_nine[15][6].$br.$td_array_nine[16][2].$fy.$td_array_nine[16][6].$br.$td_array_nine[17][2].$fy.$td_array_nine[17][6].$br.$td_array_nine[18][2].$fy.$td_array_nine[18][6].$br.$td_array_nine[19][2].$fy.$td_array_nine[19][6].$br.$td_array_nine[20][2].$fy.$td_array_nine[20][6].$br.$td_array_nine[21][2].$fy.$td_array_nine[21][6].$br.$td_array_nine[22][2].$fy.$td_array_nine[22][6].$br.$td_array_nine[23][2].$fy.$td_array_nine[23][6];
                $message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;$message = preg_replace("/;/", "", $message);
                $message = preg_replace("'([\r\n])[\s]+'", "", $message);
                $message = $year.$data_score.$br.$message.$br.$table_all;
            }
            *//*
        }
        $message = $message;
    }
    $score = $message;
    return $score;
*/

?>