<?php
function jwtz($a){
    $a = $a;
    if ($a=='abc'){
        $content =  123;
    }else{
        $url = 'http://jwc.sxdtdx.edu.cn/';
        $curl = curl_init();
        curl_setopt($curl,CURLOPT_URL,$url);
        curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
        $content = curl_exec($curl);
        curl_close($curl);
        //echo $content;


        $table = $content;

        $table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);

        preg_match_all('/通知公告([\s\S]*?) 服务平台/',$table,$kebiao); 

        //print_r($kebiao);
        //echo $kebiao[0][0];
        $table =  $kebiao[0][0];

        $table = preg_replace("/通知公告/", "", $table);
        $table = preg_replace("/更多&gt;&gt;/", "", $table);
        $table = preg_replace("/                                /", "", $table);
        $table = preg_replace("'([\r\n])[\s]+'", "", $table);


        $table = preg_replace("/<!-- 基层党建-->/", "", $table);
        $table = preg_replace("/<!--/", "", $table);
        $table = preg_replace("/-->服务平台/", "", $table);
        $table = preg_replace("/“/", "", $table);
        $table = preg_replace("/”/", "", $table);
        $table = preg_replace("/改革创新、奋发有为大讨论/", "", $table);
        $table = preg_replace("/系列报道/", "", $table);
        $table = preg_replace("/动员部署会/", "", $table);
        $table = preg_replace("/08-27/", "", $table);
        $table = preg_replace("/&gt;/", "", $table);
        $table = preg_replace("/&lt;/", "", $table);
        $table = preg_replace("'([\r\n])[\s]+'", "", $table);

        $br = "\n";
        $fy = "   ";
        $a = '<a href="http://jwc.sxdtdx.edu.cn/index.php?s=news&c=category&id=48">以下是最新通知公告-->></a>';
        $b = '<a href="http://jwc.sxdtdx.edu.cn/index.php?s=news&c=category&id=48">点我查看详情</a>';
        $c = '<a href="http://xk.btwh.xyz/back.php">我们将重新启航</a>';
        $content = $a.$br.$br.$table.$br.$br.$b.$br.$br.$c;
    }
    $content = $content;
    return $content;
}
?>