<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <haed>
        <meta charset="UTF-8">
        <title>不同传媒|教务登录</title>
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
        <meta content="yes" name="apple-mobile-web-app-capable">
        <meta content="black" name="apple-mobile-web-app-status-bar-style">
        <meta content="telephone=no" name="format-detection">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <link rel="shortcut icon" href="img/logo.ico">
        <!-- 如果使用双核浏览器，强制使用webkit来进行页面渲染 -->
        <meta name="renderer" content="webkit" />
        <!-- 网站描述 -->
        <meta name="thakns" content="致谢weui、超级大学！" /> 
        <meta name="keywords" content="微信查成绩,手机查成绩,大同大学，山西大同大学，教务查询" /> 
        <meta name="description" content="同大成绩查询，挂科成绩查询，空教室查询，等等" />
        <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
        <link rel="stylesheet" href="css/weui.min.css">
        <link rel="stylesheet" href="css/jquery-weui.css">
        <link rel="stylesheet" href="css/demos.css">
    </haed>
    <!--
    <script type="text/javascript">
     // 对浏览器的UserAgent进行正则匹配，不含有微信独有标识的则为其他浏览器
     var useragent = navigator.userAgent;
     if (useragent.match(/MicroMessenger/i) != 'MicroMessenger') {
         // 这里警告框会阻塞当前页面继续加载
         alert('同学你好，请从公众号【不同传媒】进入哦！如有其它问题请咨询微信：18235273200');
         // 以下代码是用javascript强行关闭当前页面
         var opened = window.open('about:blank', '_self');
         opened.opener = null;
         opened.close();
     }
     </script>
    -->
    <body>
        <header class='demos-header'>
          <h1 class="demos-title">教务登录</h1>
          <p class='demos-sub-title'>新系统~请重新绑定~么么哒~</p>
        </header>
        
        <form action="login.php" method="POST">

            <!--这个是获取openid，GET方式-->
             <div class="weui-cell">
                 <input type="hidden" name="openid" value="<?php $openid = $_GET["openid"];echo $openid;?>"> 
             </div>

            <!--学号开始-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">学号</label></div>
                <div class="weui-cell__bd">
                  <input class="weui-input"  name="username" placeholder="你的学号" value="">
                </div>
             </div>

            <!--密码开始-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">密码</label></div>
                <div class="weui-cell__bd">
                  <input class="weui-input"  type="password" name="password" placeholder="身份证后六位" value="">
                </div>
          </div>


        
        
        <!--登录按钮-->
        <div class="weui-btn-area">
            <input class="weui-btn weui-btn_primary"  id="showTooltips"  name="login" type='submit' value='登录'>
        </div>
            </form>
        <p class='demos-sub-title' style="font-size:11px;margin-top:2%;color:#c0c0c0;">由【不同传媒】提供此服务<br>查询表示已同意<a href="" style="color:#7AE2DB";>《用户服务协议》</a></p>
    </body>
</html>
<?php
if(isset($_POST['login'])){
    $userzjh = $_POST['username']; 
    $usermm =$_POST['password']; 
    $openid = $_POST['openid'];
    
    echo $userzjh;
    echo '</br>';
    echo $usermm;
    echo '</br>';
    echo $openid;
}else{
   if($openid==''){
	echo "系统出错，请联系微信：18235273200";
	}else{
       header("Location: http://localhost/login.php?openid=$openid");
   }
}
?>