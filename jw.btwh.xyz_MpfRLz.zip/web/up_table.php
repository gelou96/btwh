<?php
function get_array($table){
    $table = $table;
    preg_match_all('/<table width="100%" border="0" cellpadding="0" cellspacing="0" class="titleTop2">([\s\S]*?) <\/table>/',$table,$kebiao); //去掉table标签，然后/table就没用了
    $table = $kebiao[0][0];
    $table = preg_replace("/&nbsp/", "", $table);

    $table = preg_replace("'<table[^>]*?>'si", "", $table);

    $table = preg_replace("'<tr[^>]*?>'si", "", $table);
    $table = preg_replace("'<td[^>]*?>'si", "", $table);

    $table = str_replace("</tr>", "{tr}", $table);
    $table = str_replace("</td>", "{td}", $table);

    $table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);
    $table = preg_replace("'([\r\n])[\s]+'", "", $table);
    $table = preg_replace("/;/", "", $table);
    $table = str_replace(" ", "", $table);
    $table = explode('{tr}', $table);
    array_pop($table);

    foreach ($table as $key => $tr) {
            $td = explode('{td}', $tr);
            array_pop($td);
            $td_array[] = $td;
            //print_r($td);
            //echo '</br>';
    }
    return $td_array;
    
}
function up_table($openid,$table){
    $openid = $openid;
    $table = $table;
    $table = get_array($table);
    $kebiao = json_encode($table);
    $last = date('Y-m-d H:i:s');
     //开始储存到数据库
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'false';
    }else{
        //修改数据库中的数据
        $query = "UPDATE kebiao SET kebiao=?,last=? WHERE openid=?";
        $stmt =  $mysqli->prepare($query);
        $stmt -> bind_param('sss',$kebiao,$last,$openid);
        $kebiao = $kebiao;
        $last = $last;
        $openid = $openid;
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
}


?>