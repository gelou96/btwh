<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <haed>
        <meta charset="UTF-8">
        <title>不同传媒|功能中心</title>
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
        <meta content="yes" name="apple-mobile-web-app-capable">
        <meta content="black" name="apple-mobile-web-app-status-bar-style">
        <meta content="telephone=no" name="format-detection">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <link rel="shortcut icon" href="img/logo.ico">
        <!-- 如果使用双核浏览器，强制使用webkit来进行页面渲染 -->
        <meta name="renderer" content="webkit" />
        <!-- 网站描述 -->
        <meta name="thakns" content="致谢weui、超级大学！" /> 
        <meta name="keywords" content="微信查成绩,手机查成绩,大同大学，山西大同大学，教务查询" /> 
        <meta name="description" content="同大成绩查询，挂科成绩查询，空教室查询，等等" />
        <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
        <link rel="stylesheet" href="css/example.css">
        <link rel="stylesheet" href="css/weui.css">
        <link rel="stylesheet" href="css/weui.min.css">
    </haed>
    
    <script>
        function onBridgeReady() {
            WeixinJSBridge.call('hideOptionMenu');
        }
 
        if (typeof WeixinJSBridge == "undefined") {
            if (document.addEventListener) {
                document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
            } else if (document.attachEvent) {
                document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
                document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
            }
        } else {
            onBridgeReady();
        }
    </script>
    <script type="text/javascript">
        // 对浏览器的UserAgent进行正则匹配，不含有微信独有标识的则为其他浏览器
        var useragent = navigator.userAgent;
        if (useragent.match(/MicroMessenger/i) != 'MicroMessenger') {
            // 这里警告框会阻塞当前页面继续加载
            alert('同学你好，请从微信公众号【不同传媒】进入哦！如有其它问题请咨询微信：18235273200');
            // 以下代码是用javascript强行关闭当前页面
            var opened = window.open('http://jw.btwh.xyz', '_self');
            opened.opener = null;
            opened.close();
        }
    </script>
    
    <body>
        
        <style>
            .mod-pictxt4 p {display:none;}
            .mod-pictxt4 li{padding:0px 10px !important;}
            .mod-pictxt4 {
                height: 20px;
                overflow:hidden;
            }
            .mod-pictxt4 ul {
                width:100%;
                float: right;
            }
            .mod-pictxt4 h3 {
            font-size:14px;
        </style>
        <?php
        
        $time1 = strtotime(date("Y-m-d H:i:s")); //当前系统时间
        $time2 = strtotime("2020-1-14"); //放假时间
        $time3 = strtotime("2020-2-23");
        $fj = ceil(($time2-$time1)/86400);
        $kx = ceil(($time3-$time1)/86400);
        ?>
        
        <h8> <a href="https://mp.weixin.qq.com/s/8biBQiF06TW6d_6B5rRKtg" target="_blank"><img src="ad/0106.png" width=100% height=auto border="1" /></a></h8>
        <div style="background-repeat: no-repeat;background-size: 16px;background-position: 5px 4px;padding-left: 30px;padding-left: 15px;margin-top: .25em;margin-bottom: .65em;" class="mod mod-pictxt t4 mod-pictxt4" data-param="">
            <ul>
                <li><a style="color:#272636;font-size: 14px;" href="#">放假提醒 | 距离寒假还有: <?php echo $fj;?> 天。</a></li>
            </ul>
        </div>
        <div style="background-repeat: no-repeat;background-size: 16px;background-position: 5px 4px;padding-left: 30px;padding-left: 15px;margin-top: .25em;margin-bottom: .65em;" class="mod mod-pictxt t4 mod-pictxt4" data-param="">
            <ul>
                <li><a style="color:#272636;font-size: 14px;" href="#">开学提醒 | 距离上课还有: <?php echo $kx;?> 天。</a></li>
            </ul>
        </div>
       
        <div class="weui-cells">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <p style="font-size: 15px;color: #30293f;"><?php $openid=$_GET['openid'];include("nameshow.php");echo nameshow($openid);?>同学，<br>您上次更新时间为</p>
                </div>
                <a style="font-size: 15px;color:#00000;"> <?php $openid=$_GET['openid'];include("timeshow.php");echo timeshow($openid);?> </a>
            </div>
        </div>
        
        
        
        <div class="weui-cells__title">教务查询</div>
        <div class="weui-grids">
            <a href="<?php $openid=$_GET['openid'];$herf= 'Showscore.php?openid='.$openid;echo $herf; ?>" class="weui-grid">
                <div class="weui-grid__icon">
                    <img src="img/score.png" alt="">
                </div>
                <p class="weui-grid__label">成绩</p>
            </a>
            <a href="<?php $openid=$_GET['openid'];$herf= 'Showscore_yxy.php?openid='.$openid;echo $herf; ?>" class="weui-grid">
                <div class="weui-grid__icon">
                    <img src="img/yxy.png" alt="">
                </div>
                <p class="weui-grid__label">医学院点我</p>
            </a>
            <a href="<?php $openid=$_GET['openid'];$herf= 'Showtable.php?openid='.$openid;echo $herf; ?>" class="weui-grid">
                <div class="weui-grid__icon">
                    <img src="img/table.png" alt="">
                </div>
                <p class="weui-grid__label">课表</p>
            </a>
            <a href="<?php $openid=$_GET['openid'];$herf= '404.php?openid='.$openid;echo $herf; ?>" class="weui-grid">
                <div class="weui-grid__icon">
                    <img src="img/wtg.png" alt="">
                </div>
                <p class="weui-grid__label">未通过课程</p>
            </a>
            <a href="<?php $openid=$_GET['openid'];$herf= '404.php?openid='.$openid;echo $herf; ?>" class="weui-grid">
                <div class="weui-grid__icon">
                    <img src="img/nc.png" alt="">
                </div>
                <p class="weui-grid__label">内测功能</p>
            </a>
        </div>
        <div class="weui-cells__title">校内常用</div>
        <div class="weui-grids">
            <a href="https://mp.weixin.qq.com/mp/homepage?__biz=MzA4NzMyNzM0MA%3D%3D&hid=4&sn=fe96cd3cd1059a0671c9ed09ac77e484" class="weui-grid">
                <div class="weui-grid__icon">
                    <img src="img/tel.png" alt="">
                </div>
                <p class="weui-grid__label">常用电话</p>
            </a>
            <a href="https://mp.weixin.qq.com/s/9LJvpL23c2fKP7coomvrXQ" class="weui-grid">
                <div class="weui-grid__icon">
                    <img src="img/xsz.png" alt="">
                </div>
                <p class="weui-grid__label">学生证补办</p>
            </a>
        </div>
                                           
    </body>
    
    
    
    
    
    
    
    
</html>