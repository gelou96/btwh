<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <haed>
        <meta charset="utf-8">
        <title>不同传媒|教务登录</title>
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
        <meta content="yes" name="apple-mobile-web-app-capable">
        <meta content="black" name="apple-mobile-web-app-status-bar-style">
        <meta content="telephone=no" name="format-detection">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <link rel="shortcut icon" href="img/logo.ico">
        <!-- 如果使用双核浏览器，强制使用webkit来进行页面渲染 -->
        <meta name="renderer" content="webkit" />
        <!-- 网站描述 -->
        <meta name="thakns" content="致谢weui、超级大学！" /> 
        <meta name="keywords" content="微信查成绩,手机查成绩,大同大学，山西大同大学，教务查询" /> 
        <meta name="description" content="同大成绩查询，挂科成绩查询，空教室查询，等等" />
        <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
        <link rel="stylesheet" href="css/weui.min.css">
        <link rel="stylesheet" href="css/jquery-weui.css">
        <link rel="stylesheet" href="css/demos.css">
    </haed>
    
    
    <script>
        function onBridgeReady() {
            WeixinJSBridge.call('hideOptionMenu');
        }
 
        if (typeof WeixinJSBridge == "undefined") {
            if (document.addEventListener) {
                document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
            } else if (document.attachEvent) {
                document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
                document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
            }
        } else {
            onBridgeReady();
        }
    </script>
    
    <body>
        <header class='demos-header'>
          <h1 class="demos-title">教务登录</h1>
          <p class='demos-sub-title'>新系统~请重新绑定~么么哒~</p>
        </header>
        
        <form action="login.php" method="POST">

            <!--这个是获取openid，GET方式-->
             <div class="weui-cell">
                 <input type="hidden" name="openid" value="<?php $openid = $_GET["openid"];echo $openid;?>"> 
             </div>

            <!--学号开始-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">学号</label></div>
                <div class="weui-cell__bd">
                  <input class="weui-input"  name="username" placeholder="你的学号" value="">
                </div>
             </div>

            <!--密码开始-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">密码</label></div>
                <div class="weui-cell__bd">
                  <input class="weui-input"  type="password" name="password" placeholder="身份证后六位" value="">
                </div>
          </div>

        <!--登录按钮-->
        <div class="weui-btn-area">
            <input class="weui-btn weui-btn_primary"  id="showTooltips"  name="login" type='submit' value='登录'>
        </div>
            </form>
        <p class='demos-sub-title' style="font-size:11px;margin-top:2%;color:#c0c0c0;">由【不同传媒】提供此服务<br>查询表示已同意<a href="https://mp.weixin.qq.com/s/1Y5dI8fYR7PliysUtofZuw" style="color:#7AE2DB";>《用户服务协议》</a></p>
    </body>
</html>
<?php
header("Content-Type:text/html;charset=utf-8"); 

//构造虚拟ip，重点，必须有
function randIP(){
    $ip_long = array(
        array('607649792', '608174079'), //36.56.0.0-36.63.255.255
        array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
        array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
        array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
        array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
        array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
        array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
        array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
        array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
        array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
      );
    $rand_key = mt_rand(0, 9);
    $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
    $headers['CLIENT-IP'] = $ip; 
    $headers['X-FORWARDED-FOR'] = $ip; 

    $headerArr = array(); 
       foreach( $headers as $n => $v ) {
           $headerArr[] = $n .':' . $v;  
       }
       return $headerArr;    
}

$ip = randIP();
session_start();
if(isset($_POST['login'])){
    $userzjh = $_POST['username']; 
    $usermm =$_POST['password']; 
    $openid = $_POST['openid'];
    $request = "mm=$usermm&zjh=$userzjh";
    $cookie_jar = tempnam('./tmp','cookie'); //cookie储存位置
    
    //开始模拟登录
    $url_login = "http://211.82.47.6/loginAction.do";
    $curl_login = curl_init(); //初始化，获得curl句柄
    curl_setopt($curl_login,CURLOPT_URL,$url_login); 
    curl_setopt($curl_login, CURLOPT_HTTPHEADER, $ip);  //构造IP 
    curl_setopt($curl_login, CURLOPT_POST, 1); //使用post传输数据
    curl_setopt($curl_login, CURLOPT_POSTFIELDS, $request); //传递数据
    curl_setopt($curl_login, CURLOPT_COOKIEJAR, $cookie_jar); //把返回来的cookie信息保存在$cookie_jar文件中
    curl_setopt($curl_login, CURLOPT_RETURNTRANSFER, 1); //设定返回的数据是否自动显示
    curl_setopt($curl_login, CURLOPT_HEADER, false); //设定是否显示头信息
    $content_login = curl_exec($curl_login); 
    $content_login = preg_replace("'<[/!]*?[^<>]*?>'si","",$content_login);//去除html标记
    $content_login = iconv("gb2312", "utf-8",$content_login);
    $openid = $openid;
    if($openid==''){
        echo "系统出错，请联系微信：18235273200";
    }else{
        if(($userzjh=='')||($usermm=='')){
            header("Location: http://jw.btwh.xyz/web/login.php?openid=$openid");
            echo "用户名或密码不能为空";
            exit;
        }else if(substr_count($content_login,"学分制综合教务")){
            //此处判断学号密码是否正确
            //储存学号、密码，当前时间到数据库
            $openid = $openid;
            $username = $userzjh;
            $usermm = $usermm;
            include("savelogin.php");
            savelogin($openid,$username,$usermm);
            //储存结束
            curl_close($curl_login);
            
            //获取学籍信息
            //session_start();
            $url_xueji = 'http://211.82.47.6/xjInfoAction.do?oper=xjxx';
            $cookie_jar = $cookie_jar;
            $ip = $ip;
            $curl_xueji = curl_init();
            curl_setopt($curl_xueji,CURLOPT_URL,$url_xueji);
            curl_setopt($curl_xueji, CURLOPT_HTTPHEADER, $ip);  //构造IP
            curl_setopt($curl_xueji,CURLOPT_COOKIEFILE,$cookie_jar);
            curl_setopt($curl_xueji,CURLOPT_RETURNTRANSFER,1);
            $content_xueji = curl_exec($curl_xueji);
            $content_xueji= iconv("gbk", "utf-8",$content_xueji);
            /*储存学籍信息到数据库**/
            include("db.php");
            $content = $content_xueji;
            $openid = $openid;
            savexueji($content,$openid);
            //储存结束
            curl_close($curl_xueji);

            
             //获取成绩
            session_start();
            $curl_allscore = curl_init();
            $url_allscore = 'http://211.82.47.6/gradeLnAllAction.do?type=ln&oper=qbinfo&lnxndm=2016-2017学年秋(两学期)#2018-2019%E5%AD%A6%E5%B9%B4%E7%A7%8B(%E4%B8%A4%E5%AD%A6%E6%9C%9F)';
            $cookie_jar = $cookie_jar;
            $ip = $ip;
            curl_setopt($curl_allscore,CURLOPT_URL,$url_allscore);
            curl_setopt($curl_allscore, CURLOPT_HTTPHEADER, $ip);  //构造IP 
            curl_setopt($curl_allscore,CURLOPT_COOKIEFILE,$cookie_jar);
            curl_setopt($curl_allscore,CURLOPT_RETURNTRANSFER,1);
            $content_allscore = curl_exec($curl_allscore);
            $content_allscore = iconv("gb2312", "utf-8",$content_allscore);
            //echo $content_allscore;
            curl_close($curl_allscore);

            //储存到数据库
            $openid = $openid;
            $allscore = $content_allscore;
            include('class.php');
            class_allscore($openid,$allscore);

            //获取课表
            session_start();
            $ip = $ip;
            $curl_table = curl_init();
            $url_table = 'http://211.82.47.6/xkAction.do?actionType=6'; //(2019.1.31 需在此处换个链接)
            curl_setopt($curl_table,CURLOPT_URL,$url_table);
            curl_setopt($curl_table, CURLOPT_HTTPHEADER, $ip);  //构造IP 
            curl_setopt($curl_table,CURLOPT_COOKIEFILE,$cookie_jar);
            curl_setopt($curl_table,CURLOPT_RETURNTRANSFER,1);
            $content_table = curl_exec($curl_table);
            $content_table = iconv("gb2312", "utf-8",$content_table);
            //echo $content_table;
            curl_close($curl_table );

            //将课表储存到数据库
            $openid = $openid;
            $table = $content_table;
            include('savetable.php');
            table($openid,$table);
            
            header("Location: http://jw.btwh.xyz/web/function.php?openid=$openid");
        }else{
            echo "学号或密码错误！"; 
			header("Location: http://jw.btwh.xyz/web/login.php?openid=$openid");
            echo "学号或密码错误！"; 
            exit;
        }
    }
    
}
?>
                

                                                                       
                                                   
                                                   
                                                   
                                                   
                                                   
                                                   
                                                   
                                                   
                                                   
