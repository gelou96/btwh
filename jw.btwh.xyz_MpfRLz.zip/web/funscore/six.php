<?php
function six($openid){
    $openid = $openid;
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        echo 'The connection is false,please test again or wait a time! The best way to solve the problem is add my wechat——>>18235273200（阁楼） ';
    }else{
        $mysqli->query("set names utf8" );
        $result = $mysqli->query ("SELECT six FROM score WHERE openid='$openid'");
        while ( list ( $six ) = $result->fetch_row() ){
            $six1 = $six;
        }
        $result->close (); // 【不同传媒】
        $mysqli->close ();
    }
    $td_array_six = json_decode($six1, true);
    if($six1=='null'){
    	echo '<td>';
		echo '宝贝，你还有没这学期成绩哦！';
		echo '</td>';
    }else{
        for($i=6;;$i++){
			if($td_array_six[$i][2]== ''){
				break;
			}	
		}
        $no = 0;
        $jd_xf = 0;
	    $xf = 0;
	    $cj = 0;
        for($a = 6;$a<=$i-1;$a++){
			echo '<tr>';
			echo '<td>';
			print_r($td_array_six[$a][2]);//科目名称
			echo '</td>';
			echo '<td>';
			print_r($td_array_six[$a][4]);//学分
			echo '</td>';
			echo '<td>';
			print_r($td_array_six[$a][5]);//课程属性
			echo '</td>';
			echo '<td>';
			print_r($td_array_six[$a][6]);//分数
			echo '</td>';
			echo '</tr>';
		}
    }
}
?>