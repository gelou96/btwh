<?php
/*此文件只关于储存数据到数据库*/
/*2019.12.30*/

//储存学号、密码、当前时间到数据库
/*
function savelogin($openid,$username,$usermm){
    $openid = $openid;
    $xh = $username;
    $mm = $usermm;
    $first = date('Y-m-d h:i:s', time());
    $last = date('Y-m-d h:i:s', time());
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'The connection is false,please test again or wait a time!';
    }else{
        $query = "INSERT INTO bindmessage(openid,xh,mm,first,last) VALUES(?,?,?,?,?)";
        $stmt =  $mysqli->prepare($query);
        $stmt->bind_param('sssss',$openid,$xh,$mm,$first,$last);
        $openid = $openid;
        $xh = $xh;
        $mm = $mm;
        $first = $first;
        $last = $last;
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
    
}
*/
//只储存最后更新时间到数据库
function savelast($openid){
    $openid = $openid;
    $last = date('Y-m-d h:i:s');
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'The connection is false,please test again or wait a time!';
    }else{
        //修改数据库中的数据
        $query = "UPDATE bindmessage SET last=? WHERE openid=?";
        $stmt =  $mysqli->prepare($query);
        $stmt->bind_param('ss',$last,$openid);
        $last = $last;
        $openid = $openid;
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
}

//储存学籍信息到数据库
function savexueji($content,$openid){
    $content = $content;
    $openid = $openid;
    //$html= iconv("gbk", "utf-8",$content);
    $table = $content;
    $table = preg_replace("'<table[^>]*?>'si","",$table);
    $table = preg_replace('/&nbsp;/',"",$table);  //去掉&nbsp，这个有用
    $table = str_replace(" ","",$table); //去掉半角空格
    $table = str_replace(" ","",$table);  //去掉全角空

    $table = preg_replace("'<tr[^>]*?>'si","",$table); //去掉tr标签，然后/tr就没用了
    $table = preg_replace("'<td[^>]*?>'si","",$table);//去掉td标签，然后/tr就没用了

    $table = str_replace("</tr>","{tr}",$table); //用｛tr｝代替<tr>
    $table = str_replace("</td>","{td}",$table); //用｛td｝代替<td>

    $table = preg_replace("'<[/!]*?[^<>]*?>'si","",$table);//去除html标记

    $table = preg_replace("'([\r\n])[\s]+'","",$table);  //去掉空白字符,实践证明这个有

    $table = str_replace("\n","",$table);
    $table = str_replace("\n\n","",$table);
    $table = str_replace("//","",$table);
    $table = explode('{tr}', $table);
    foreach ($table as $key=>$value){
        $td = explode('{td}', $value);
        array_pop($td);
        $td_array[] = $td;
    }
    $xuehao = $td_array[7][2];//学号
    
    $name = $td_array[7][4];//姓名

    $sex = $td_array[8][9];//性别

    $xueyuan = $td_array[8][47];//学院

    $banji = $td_array[8][55];//班级

    $nianji = $td_array[8][53];//年级
    
    $rxqr = $td_array[8][45];//入学日期
    
    //开始储存
    $openid = $openid;
    $xuehao = $xuehao;
    $name = $name;
    $sex = $sex;
    $xueyuan = $xueyuan;
    $banji = $banji;
    $nianji = $nianji;
    $rxrq = $rxqr;
    $date = date('Y-m-d H:i:s');
    
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'The connection is false,please test again or wait a time!';
    }else{
        $query = "INSERT INTO xueji(openid,xuehao,name,sex,nianji,xueyuan,banji,rxrq,date) VALUES(?,?,?,?,?,?,?,?,?)";
        $stmt =  $mysqli->prepare($query);
        $stmt->bind_param('sisssssss',$openid,$xuehao,$name,$sex,$nianji,$xueyuan,$banji,$rxrq,$date);
        $openid = $openid;
        $xuehao = $xuehao;
        $name = $name;
        $sex = $sex;
        $xueyuan = $xueyuan;
        $banji = $banji;
        $nianji = $nianji;
        $rxrq = $rxqr;
        $date = $date;
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
    
}
?>