<?php
//将更新日期储存到bingmessage数据库
function upsavelast($openid){
    $openid = $openid;
    $last = date('Y-m-d H:i:s');
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'The connection is false,please test again or wait a time!';
    }else{
        //修改数据库中的数据
        $query = "UPDATE bindmessage SET last=? WHERE openid=?";
        $stmt =  $mysqli->prepare($query);
        $stmt->bind_param('ss',$last,$openid);
        $last = $last;
        $openid = $openid;
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
}
?>

<?php
//将更新后成绩，更新时间出存到数据库
function get_td_array($table){
    $table = preg_replace("/&nbsp/", "", $table);
    $table = preg_replace("/;/", "", $table);
    $table = preg_replace("/ /", "", $table);
    $table = preg_replace("'<table[^>]*?>'si", "", $table);

    $table = preg_replace("'<tr[^>]*?>'si", "", $table);
    $table = preg_replace("'<td[^>]*?>'si", "", $table);

    $table = str_replace("</tr>", "{tr}", $table);
    $table = str_replace("</td>", "{td}", $table);

    $table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);
    $table = preg_replace("'([\r\n])[\s]+'", "", $table);
    $table = str_replace(" ", "", $table);
    $table = explode('{tr}', $table);
    array_pop($table);
    foreach ($table as $key => $tr) {
            $td = explode('{td}', $tr);
            array_pop($td);
            $td_array[] = $td;
            //print_r($td);
            //echo '</br>';
        
	}
    return $td_array;
}

function upsavescore($openid,$allscore){
    $openid = $openid;
    $allscore = $allscore;
    $table = $allscore;
    preg_match_all('/<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">([\s\S]*?) <\/table>/',$table,$score); 
    //大一第一学期
    $zero = $score[0][0];
    $zero = get_td_array($zero);
    $zero = json_encode($zero);

    //大一第二学期
    $one = $score[0][1];
    $one = get_td_array($one);
    $one = json_encode($one);

    //大二第一学期
    $two = $score[0][2];
    $two = get_td_array($two);
    $two = json_encode($two);

    //大二第二学期
    $three = $score[0][3];
    $three = get_td_array($three);
    $three = json_encode($three);

    //大三第一学期
    $four = $score[0][4];
    $four = get_td_array($four);
    $four = json_encode($four);

    //大三第二学期
    $five = $score[0][5];
    $five = get_td_array($five);
    $five = json_encode($five);

    //大四第一学期
    $six = $score[0][6];
    $six = get_td_array($six);
    $six = json_encode($six);

    //大四第二学期
    $seven = $score[0][7];
    $seven = get_td_array($seven);
    $seven = json_encode($seven);

    //大五第一学期
    $eight = $score[0][8];
    $eight = get_td_array($eight);
    $eight = json_encode($eight);

    //大五第二学期
    $nine = $score[0][9];
    $nine = get_td_array($nine);
    $nine = json_encode($nine);
    
    //更新数据到数据库
    $zero = $zero;
    $one = $one;
    $two = $two;
    $three = $three;
    $four = $four;
    $five = $five;
    $six = $six;
    $seven = $seven;
    $eight = $eight;
    $nine = $nine;
    $last = date('Y-m-d H:i:s');
    
    $openid = $openid;
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'false';
    }else{
        //修改数据库中的数据
        $query = "UPDATE score SET zero=?,one=?,two=?,three=?,four=?,five=?,six=?,seven=?,eight=?,nine=?,last=? WHERE openid=?";
        $stmt =  $mysqli->prepare($query);
        $stmt->bind_param('ssssssssssss',$zero,$one,$two,$three,$four,$five,$six,$seven,$eight,$nine,$last,$openid);
        $zero = $zero;
        $one = $one;
        $two = $two;
        $three = $three;
        $four = $four;
        $five = $five;
        $six = $six;
        $seven = $seven;
        $eight = $eight;
        $nine = $nine;
        $last = $last;
        $openid = $openid;
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
}

?>