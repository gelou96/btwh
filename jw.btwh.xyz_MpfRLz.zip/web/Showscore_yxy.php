<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        
        <meta charset="UTF-8">
        <title>不同文化|成绩单</title>
        <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport">
        <meta content="yes" name="apple-mobile-web-app-capable">
        <meta content="black" name="apple-mobile-web-app-status-bar-style">
        <meta content="telephone=no" name="format-detection">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
        <!-- 如果使用双核浏览器，强制使用webkit来进行页面渲染 -->
        <meta name="renderer" content="webkit" />
        <!-- 网站描述 -->
        <meta name="description" content="不同文化|微信教务" />
        <!-- 网站搜索关键词 -->
        <meta name="keywords" content="微信，大同大学">
        <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
        <link rel="shortcut icon" href="img/logo.ico">
        <link rel="stylesheet" href="css/grade.css">
        <link rel="stylesheet" href="css/weui.css">
        
         <script type="text/javascript" >
            $(document).ready(function() {
                $(".navbar>div").on('click', function(event) {
                    $(".selected").removeClass('selected');
                    $(this).addClass('selected');
                    $(".grades").hide().eq($(this).index()).show();
                    /* Act on the event */
                });
                $(".code").on("click",function(){
                    codeClick();
                });
            });
        </script>

    </head>
    
    <script>
        function onBridgeReady() {
            WeixinJSBridge.call('hideOptionMenu');
        }
 
        if (typeof WeixinJSBridge == "undefined") {
            if (document.addEventListener) {
                document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
            } else if (document.attachEvent) {
                document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
                document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
            }
        } else {
            onBridgeReady();
        }
    </script>
    <script type="text/javascript">
        // 对浏览器的UserAgent进行正则匹配，不含有微信独有标识的则为其他浏览器
        var useragent = navigator.userAgent;
        if (useragent.match(/MicroMessenger/i) != 'MicroMessenger') {
            // 这里警告框会阻塞当前页面继续加载
            alert('同学你好，请从微信公众号【不同传媒】进入哦！如有其它问题请咨询微信：18235273200');
            // 以下代码是用javascript强行关闭当前页面
            var opened = window.open('http://jw.btwh.xyz', '_self');
            opened.opener = null;
            opened.close();
        }
    </script>
    
    <body>
        
        <header>
            <?php $openid = $_GET['openid']; ?>
            <span class="school">山西大同大学</span>
            <span class="supply"><a href="<?php $openid=$_GET['openid'];$herf= 'login.php?openid='.$openid;echo $herf; ?>">重新绑定</a></span>
            <h4><?php $openid=$_GET['openid'];include("nameshow.php");echo nameshow($openid);?>的成绩单</h4>
            <span class="gpa">您上次更新时间：<?php $openid=$_GET['openid'];include("timeshow.php");echo timeshow($openid);?></span>
            <span class="update"><a href="<?php $openid=$_GET['openid'];$herf= 'update.php?openid='.$openid;echo $herf; ?>">更新</a></span>
        </header>
        <div class="outter">
    	<div class="navbar">
	        <div class="selected">大一</div>
	        <div>大二</div>
	        <div>大三</div>
	        <div>大四</div>
            <div>大五</div>
    	</div>
        </div>
        <?php $openid = $_GET['openid']; ?>
        <!--大一-->
        <div class="grades">
    	<div class="term" >第一学期</div>
    	<div class="table" >
    		<table>
    			<thead>
    				<tr>
    					<th width="55%">课程名</th>
    					<th>学分</th>
    					<th>课程属性</th>
    					<th>成绩</th>
    				</tr>
    				<?php include("./funscore/zero.php");echo zero($openid);?>
    			</thead>
    			<tbody>
  
    			</tbody>
    		</table>
    	</div>
    	<div class="term" >第二学期</div>
    	<div class="table" >
    		<table>
    			<thead>
    				<tr>
    					<th width="55%">课程名</th>
    					<th>学分</th>
    					<th>课程属性</th>
    					<th>成绩</th>
    				</tr>
    				<?php include("./funscore/one.php");echo one($openid);?>
    			</thead>
    			<tbody>
    				
    			</tbody>
    		</table>
    	</div>
    </div>
    <!--大二-->
    <div class="grades" hidden>
    	<div class="term" >第一学期</div>
    	<div class="table" >
    		<table>
    			<thead>
    				<tr>
    					<th width="55%">课程名</th>
    					<th>学分</th>
    					<th>课程属性</th>
    					<th>成绩</th>
    				</tr>
    				<?php include("./funscore/two.php");echo two($openid);?>
    			</thead>
    			<tbody>
  
    			</tbody>
    		</table>
    	</div>
    	<div class="term" >第二学期</div>
    	<div class="table" >
    		<table>
    			<thead>
    				<tr>
    					<th width="55%">课程名</th>
    					<th>学分</th>
    					<th>课程属性</th>
    					<th>成绩</th>
    				</tr>
    				<?php include("./funscore/three.php");echo three($openid);?>
    			</thead>
    			<tbody>
    				
    			</tbody>
    		</table>
    	</div>
    </div>
    
    <!--大三-->
    <div class="grades" hidden>
    	<div class="term" >第一学期</div>
    	<div class="table" >
    		<table>
    			<thead>
    				<tr>
    					<th width="55%">课程名</th>
    					<th>学分</th>
    					<th>课程属性</th>
    					<th>成绩</th>
    				</tr>
    				<?php include("./funscore/four.php");echo four($openid);?>
    			</thead>
    			<tbody>
  
    			</tbody>
    		</table>
    	</div>
    	<div class="term" >第二学期</div>
    	<div class="table" >
    		<table>
    			<thead>
    				<tr>
    					<th width="55%">课程名</th>
    					<th>学分</th>
    					<th>课程属性</th>
    					<th>成绩</th>
    				</tr>
    				<?php include("./funscore/five.php");echo five($openid);?>
    			</thead>
    			<tbody>
    				
    			</tbody>
    		</table>
    	</div>
    </div>
    
    <!--大四-->
    <div class="grades" hidden>
    	<div class="term" >第一学期</div>
    	<div class="table" >
    		<table>
    			<thead>
    				<tr>
    					<th width="55%">课程名</th>
    					<th>学分</th>
    					<th>课程属性</th>
    					<th>成绩</th>
    				</tr>
    				<?php include("./funscore/six.php");echo six($openid);?>
    			</thead>
    			<tbody>
  
    			</tbody>
    		</table>
    	</div>
    	<div class="term" >第二学期</div>
    	<div class="table" >
    		<table>
    			<thead>
    				<tr>
    					<th width="55%">课程名</th>
    					<th>学分</th>
    					<th>课程属性</th>
    					<th>成绩</th>
    				</tr>
    				<?php include("./funscore/seven.php");echo seven($openid);?>
    			</thead>
    			<tbody>
    				
    			</tbody>
    		</table>
    	</div>
    </div>
        
        
    <!--大五-->
    <div class="grades" hidden>
    	<div class="term" >第一学期</div>
    	<div class="table" >
    		<table>
    			<thead>
    				<tr>
    					<th width="55%">课程名</th>
    					<th>学分</th>
    					<th>课程属性</th>
    					<th>成绩</th>
    				</tr>
    				<?php include("./funscore/eight.php");echo eight($openid);?>
    			</thead>
    			<tbody>
  
    			</tbody>
    		</table>
    	</div>
    	<div class="term" >第二学期</div>
    	<div class="table" >
    		<table>
    			<thead>
    				<tr>
    					<th width="55%">课程名</th>
    					<th>学分</th>
    					<th>课程属性</th>
    					<th>成绩</th>
    				</tr>
    				<?php include("./funscore/nine.php");echo nine($openid);?>
    			</thead>
    			<tbody>
    				
    			</tbody>
    		</table>
    	</div>
    </div>        
        
        
    <div class="append">
    </div>    
    
        
    <!-- <!-- 提示框 -->
    <!--<div class="weui_toptips weui_warn js_tooltips"></div>-->
    <nav>
        <div><a href="<?php $openid=$_GET['openid'];$herf= 'function.php?openid='.$openid;echo $herf; ?>"><img src="img/zy.png"><br/>主界面</a></div>
        <div><a class="on"><img src="img/grade.png"><br/>成绩</a></div>
        <div><a href="<?php $openid=$_GET['openid'];$herf= 'GPA.php?openid='.$openid;echo $herf; ?>"><img src="img/GPA.png"><br/>GPA</a></div>
        <div><a href="<?php $openid=$_GET['openid'];$herf= 'Showtable.php?openid='.$openid;echo $herf; ?>"><img src="img/timetable.png"><br/>课表</a></div>
    	
      
    </nav>    
        
        
    </body>
    
    
    
    
    
    
    
    
</html>