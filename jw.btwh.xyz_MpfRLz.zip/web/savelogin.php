<?php
function savelogin($openid,$username,$usermm){
    $openid = $openid;
    $xh = $username;
    $mm = $usermm;
    $first = date('Y-m-d H:i:s');
    $last = date('Y-m-d H:i:s');
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'The connection is false,please test again or wait a time!';
    }else{
        $query = "INSERT INTO bindmessage(openid,xh,mm,first,last) VALUES(?,?,?,?,?)";
        $stmt =  $mysqli->prepare($query);
        $stmt->bind_param('sssss',$openid,$xh,$mm,$first,$last);
        $openid = $openid;
        $xh = $xh;
        $mm = $mm;
        $first = $first;
        $last = $last;
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
}
?>