<?php
//此文件根据openid来获取学号
//2020.1.4

function updatexh($openid){
    $openid = $openid;
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'The connection is false,please test again or wait a time!';
    }else{
        $openid = $openid;
        $mysqli->query("set names utf8" );
        $result = $mysqli->query ("SELECT xh FROM bindmessage WHERE openid='$openid'");
        while ( list ( $xh ) = $result->fetch_row() ){
            $xuehao = $xh;
        }
        $result->close (); // 关闭结果集
        $mysqli->close ();
    }
    $xuehao = preg_replace("/;/", "", $xuehao);
    $xuehao = preg_replace("'([\r\n])[\s]+'", "", $xuehao);
    return $xuehao;
}
?>