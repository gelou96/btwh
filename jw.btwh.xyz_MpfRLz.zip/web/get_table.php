<?php
function kb($openid,$x,$y){
    $openid = $openid;
    $x = $x;
    $y = $y;
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        echo 'The connection is false,please test again or wait a time! The best way to solve the problem is add my wechat——>>18235273200（阁楼） ';
    }else{
        $mysqli->query("set names utf8" );
        $result = $mysqli->query ("SELECT kebiao FROM kebiao WHERE openid='$openid'");
        while ( list ( $kebiao ) = $result->fetch_row() ){
            $kb = $kebiao;
        }
        $result->close (); // 【不同传媒】
        $mysqli->close ();
    }
    $td_array = json_decode($kb, true);
    
    //周一
    $td_array[0][0]=$td_array[1][0]; //上午
    $td_array[0][1]=$td_array[1][2]; //第一节课
    $td_array[0][2]=$td_array[3][1]; //第二节课
    $td_array[0][3]=$td_array[6][0]; //下午
    $td_array[0][4]=$td_array[6][2]; //第一节课
    $td_array[0][5]=$td_array[8][1]; //第二节课
    $td_array[0][6]=$td_array[11][0]; //晚上
    $td_array[0][7]=$td_array[11][2]; //第一节课

    //周日
    $td_array[6][1]=$td_array[1][8]; //周日第一节课

    //周六
    $td_array[5][1]=$td_array[1][7]; //周六第一节课

    //周五
    $td_array[4][1]=$td_array[1][6]; //周五第一节课

    //周四
    $td_array[3][1]=$td_array[1][5]; //周四第一节课

    //周三
    $td_array[2][1]=$td_array[1][4]; //周三第一节课

    //周二
    $td_array[1][0]=$td_array[0][0]; //上午
    $td_array[1][1]=$td_array[1][3]; //第一节课
    $td_array[1][2]=$td_array[3][2]; //第二节课
    $td_array[1][3]=$td_array[0][3]; //下午
    $td_array[1][4]=$td_array[6][3]; //第一节课
    $td_array[1][5]=$td_array[8][2]; //第二节课
    $td_array[1][6]=$td_array[0][6]; //晚上
    $td_array[1][7]=$td_array[11][3]; //第一节课

    //周三
    $td_array[2][0]=$td_array[0][0]; //上午

    $td_array[2][2]=$td_array[3][3]; //第二节课
    $td_array[2][3]=$td_array[0][3]; //下午
    $td_array[2][4]=$td_array[6][4]; //第一节课
    $td_array[2][5]=$td_array[8][3]; //第二节课
    $td_array[2][6]=$td_array[0][6]; //晚上
    $td_array[2][7]=$td_array[11][4]; //第一节课

    //周日
    $td_array[6][2]=$td_array[3][7]; //周日第二节课

    //周六
    $td_array[5][2]=$td_array[3][6]; //周六第二节课

    //周五
    $td_array[4][2]=$td_array[3][5]; //周五第二节课

    //周四
    $td_array[3][0]=$td_array[0][0]; //上午

    $td_array[3][2]=$td_array[3][4]; //第二节课
    $td_array[3][3]=$td_array[0][3]; //下午
    $td_array[3][4]=$td_array[6][5]; //第一节课
    $td_array[3][5]=$td_array[8][4]; //第二节课
    $td_array[3][6]=$td_array[0][6]; //晚上
    $td_array[3][7]=$td_array[11][5]; //第一节课

    //周五
    $td_array[4][0]=$td_array[0][0]; //上午


    $td_array[4][3]=$td_array[0][3]; //下午
    $td_array[4][4]=$td_array[6][6]; //第一节课
    $td_array[4][5]=$td_array[8][5]; //第二节课
    $td_array[4][6]=$td_array[0][6]; //晚上
    $td_array[4][7]=$td_array[11][6]; //第一节课

    //周六
    $td_array[5][0]=$td_array[0][0]; //上午


    $td_array[5][3]=$td_array[0][3]; //下午
    $td_array[5][4]=$td_array[6][7]; //第一节课
    $td_array[5][5]=$td_array[8][6]; //第二节课
    $td_array[5][6]=$td_array[0][6]; //晚上
    $td_array[5][7]=$td_array[11][7]; //第一节课

    //周日
    $td_array[6][0]=$td_array[0][0]; //上午


    $td_array[6][3]=$td_array[0][3]; //下午
    $td_array[6][4]=$td_array[6][8]; //第一节课
    $td_array[6][5]=$td_array[8][7]; //第二节课
    $td_array[6][6]=$td_array[0][6]; //晚上
    $td_array[6][7]=$td_array[11][8]; //第一节课
    
    $kebiao = $td_array[$x][$y];
    $content = preg_replace("'([\r\n])[\s]+'", "", $kebiao);
    return $content;
    
}

?>