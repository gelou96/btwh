<?php
function timeshow($openid){
    $openid = $openid;
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'The connection is false,please test again or wait a time!';
    }else{
        $openid = $openid;
        $mysqli->query("set names utf8" );
        $result = $mysqli->query ("SELECT last FROM bindmessage WHERE openid='$openid'");
        while ( list ( $last ) = $result->fetch_row() ){
            $time = $last;
        }
        $result->close (); // 关闭结果集
        $mysqli->close ();
    }
    $time = preg_replace("/;/", "", $time);
    $time = preg_replace("'([\r\n])[\s]+'", "", $time);
	return $time;
}
?>