<?php
/*用途：将所有成绩分成每学期成绩
  时间：2019.12.31
  阁楼~么么哒
*/
function get_td_array($table){
    $table = preg_replace("/&nbsp/", "", $table);
    $table = preg_replace("/;/", "", $table);
    $table = preg_replace("/ /", "", $table);
    $table = preg_replace("'<table[^>]*?>'si", "", $table);

    $table = preg_replace("'<tr[^>]*?>'si", "", $table);
    $table = preg_replace("'<td[^>]*?>'si", "", $table);

    $table = str_replace("</tr>", "{tr}", $table);
    $table = str_replace("</td>", "{td}", $table);

    $table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);
    $table = preg_replace("'([\r\n])[\s]+'", "", $table);
    $table = str_replace(" ", "", $table);
    $table = explode('{tr}', $table);
    array_pop($table);
    foreach ($table as $key => $tr) {
            $td = explode('{td}', $tr);
            array_pop($td);
            $td_array[] = $td;
            //print_r($td);
            //echo '</br>';
        
	}
    return $td_array;
}


function class_allscore($openid,$allscore){
    $openid = $openid;
    $allscore = $allscore;
    $table = $allscore;
    preg_match_all('/<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">([\s\S]*?) <\/table>/',$table,$score); 
    //大一第一学期
    $zero = $score[0][0];
    $zero = get_td_array($zero);
    $zero = json_encode($zero);

    //大一第二学期
    $one = $score[0][1];
    $one = get_td_array($one);
    $one = json_encode($one);

    //大二第一学期
    $two = $score[0][2];
    $two = get_td_array($two);
    $two = json_encode($two);

    //大二第二学期
    $three = $score[0][3];
    $three = get_td_array($three);
    $three = json_encode($three);

    //大三第一学期
    $four = $score[0][4];
    $four = get_td_array($four);
    $four = json_encode($four);

    //大三第二学期
    $five = $score[0][5];
    $five = get_td_array($five);
    $five = json_encode($five);

    //大四第一学期
    $six = $score[0][6];
    $six = get_td_array($six);
    $six = json_encode($six);

    //大四第二学期
    $seven = $score[0][7];
    $seven = get_td_array($seven);
    $seven = json_encode($seven);

    //大五第一学期
    $eight = $score[0][8];
    $eight = get_td_array($eight);
    $eight = json_encode($eight);

    //大五第二学期
    $nine = $score[0][9];
    $nine = get_td_array($nine);
    $nine = json_encode($nine);
    
    //开始储存数据到数据库
    $openid = $openid;
    $zero = $zero;
    $one = $one;
    $two = $two;
    $three = $three;
    $four = $four;
    $five = $five;
    $six = $six;
    $seven = $seven;
    $eight = $eight;
    $nine = $nine;
    $first = date('Y-m-d h:i:s', time());
    $last = date('Y-m-d h:i:s', time());
    
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'false';
    }else{
        //echo 'success';
        $query = "INSERT INTO score(openid,zero,one,two,three,four,five,six,seven,eight,nine,first,last) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
        $stmt =  $mysqli->prepare($query);
        $stmt -> bind_param('sssssssssssss',$openid,$zero,$one,$two,$three,$four,$five,$six,$seven,$eight,$nine,$first,$last);
        $openid = $openid;
        $zero = $zero;
        $one = $one;
        $two = $two;
        $three = $three;
        $four = $four;
        $five = $five;
        $six = $six;
        $seven = $seven;
        $eight = $eight;
        $nine = $nine;
        $first = $first;
        $last = $last;
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
    
    
    
    
}

?>