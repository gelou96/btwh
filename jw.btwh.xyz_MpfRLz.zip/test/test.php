<?php
/*
//测试 header("Location: http://dtxtcm.cn/login.php?openid=$openid");
$openid = $_GET["openid"];
echo $openid;
echo '</br>';
if($openid==''){
    echo '系统出错，请联系微信：18235273200';
}else{
    //echo 'success';
    header("Location: http://localhost/btwh/web/login.php?openid=$openid");
}
*/
/*
//测试学籍信息编码
$userzjh = '160807051237'; 
$usermm ='143913'; 
//$openid = $_POST['openid'];
$request = "mm=$usermm&zjh=$userzjh";
$cookie_jar = tempnam('./tmp','cookie'); //cookie储存位置

//开始模拟登录
$url_login = "http://211.82.47.6/loginAction.do";
$curl_login = curl_init(); //初始化，获得curl句柄
curl_setopt($curl_login,CURLOPT_URL,$url_login); 
//curl_setopt($curl_login, CURLOPT_HTTPHEADER, $ip);  //构造IP 
curl_setopt($curl_login, CURLOPT_POST, 1); //使用post传输数据
curl_setopt($curl_login, CURLOPT_POSTFIELDS, $request); //传递数据
curl_setopt($curl_login, CURLOPT_COOKIEJAR, $cookie_jar); //把返回来的cookie信息保存在$cookie_jar文件中
curl_setopt($curl_login, CURLOPT_RETURNTRANSFER, 1); //设定返回的数据是否自动显示
curl_setopt($curl_login, CURLOPT_HEADER, false); //设定是否显示头信息
$content_login = curl_exec($curl_login); 
$content_login = preg_replace("'<[/!]*?[^<>]*?>'si","",$content_login);//去除html标记
$content_login = iconv("gb2312", "utf-8",$content_login);
//echo $content_login;
curl_close($curl_login);
session_start();
$url_xueji = 'http://211.82.47.6/xjInfoAction.do?oper=xjxx';
$cookie_jar = $cookie_jar;
$ip = $ip;
$curl_xueji = curl_init();
curl_setopt($curl_xueji,CURLOPT_URL,$url_xueji);
//curl_setopt($curl_xueji, CURLOPT_HTTPHEADER, $ip);  //构造IP
curl_setopt($curl_xueji,CURLOPT_COOKIEFILE,$cookie_jar);
curl_setopt($curl_xueji,CURLOPT_RETURNTRANSFER,1);
$content_xueji = curl_exec($curl_xueji);
$content_xueji= iconv("gbk", "utf-8",$content_xueji);
/*储存学籍信息到数据库**/
/*
curl_close($curl_xueji);
//echo $content_xueji;
$html = $content_xueji;
//$html= iconv("gbk", "utf-8",$content);
//echo $html;
$table = $html;
$table = preg_replace("'<table[^>]*?>'si","",$table);
$table = preg_replace('/&nbsp;/',"",$table);  //去掉&nbsp，这个有用
$table = str_replace(" ","",$table); //去掉半角空格
$table = str_replace(" ","",$table);  //去掉全角空

$table = preg_replace("'<tr[^>]*?>'si","",$table); //去掉tr标签，然后/tr就没用了
$table = preg_replace("'<td[^>]*?>'si","",$table);//去掉td标签，然后/tr就没用了

$table = str_replace("</tr>","{tr}",$table); //用｛tr｝代替<tr>
$table = str_replace("</td>","{td}",$table); //用｛td｝代替<td>

$table = preg_replace("'<[/!]*?[^<>]*?>'si","",$table);//去除html标记

$table = preg_replace("'([\r\n])[\s]+'","",$table);  //去掉空白字符,实践证明这个有

$table = str_replace("\n","",$table);
$table = str_replace("\n\n","",$table);
$table = str_replace("//","",$table);
$table = explode('{tr}', $table);
foreach ($table as $key=>$value){
    $td = explode('{td}', $value);
    array_pop($td);
    $td_array[] = $td;
    //print_r($td_array[8][45]);
    //print_r($td);
    //echo "<br/>";
}
*/
//构造虚拟ip，重点，必须有
function randIP(){
       $ip_long = array(
           array('607649792', '608174079'), //36.56.0.0-36.63.255.255
           array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
           array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
           array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
           array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
           array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
           array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
           array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
           array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
           array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
       );
       $rand_key = mt_rand(0, 9);
       $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
       $headers['CLIENT-IP'] = $ip; 
       $headers['X-FORWARDED-FOR'] = $ip; 

       $headerArr = array(); 
       foreach( $headers as $n => $v ) { 
           $headerArr[] = $n .':' . $v;  
       }
       return $headerArr;    
   }
   
$ip = randIP();
print_r($ip);
echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';
$userzjh = '160807051237'; 
$usermm ='143913'; 
//$userzjh = '190807051136';
//$usermm = '020514';
$openid = 'asdasjsadhkj1dsa1das2';
$request = "mm=$usermm&zjh=$userzjh";
$cookie_jar = tempnam('./tmp','cookie'); //cookie储存位置
//开始模拟登录
$url_login = "http://211.82.47.6/loginAction.do";
$curl_login = curl_init(); //初始化，获得curl句柄
curl_setopt($curl_login,CURLOPT_URL,$url_login); 
curl_setopt($curl_login, CURLOPT_HTTPHEADER, $ip);  //构造IP 
curl_setopt($curl_login, CURLOPT_POST, 1); //使用post传输数据
curl_setopt($curl_login, CURLOPT_POSTFIELDS, $request); //传递数据
curl_setopt($curl_login, CURLOPT_COOKIEJAR, $cookie_jar); //把返回来的cookie信息保存在$cookie_jar文件中
curl_setopt($curl_login, CURLOPT_RETURNTRANSFER, 1); //设定返回的数据是否自动显示
curl_setopt($curl_login, CURLOPT_HEADER, false); //设定是否显示头信息
$content_login = curl_exec($curl_login); 
$content_login = preg_replace("'<[/!]*?[^<>]*?>'si","",$content_login);//去除html标记
$content_login = iconv("gb2312", "utf-8",$content_login);
//echo $content_login;
curl_close($curl_login);
/*
//获取学籍信息
session_start();
$url_xueji = 'http://211.82.47.6/xjInfoAction.do?oper=xjxx';
$cookie_jar = $cookie_jar;
$ip = $ip;
$curl_xueji = curl_init();
curl_setopt($curl_xueji,CURLOPT_URL,$url_xueji);
curl_setopt($curl_xueji, CURLOPT_HTTPHEADER, $ip);  //构造IP
curl_setopt($curl_xueji,CURLOPT_COOKIEFILE,$cookie_jar);
curl_setopt($curl_xueji,CURLOPT_RETURNTRANSFER,1);
$content_xueji = curl_exec($curl_xueji);
$content_xueji= iconv("gbk", "utf-8",$content_xueji);
/*储存学籍信息到数据库**/
/*
include("db.php");
$content = $content_xueji;
$openid = $openid;
savexueji($content,$openid);
//储存结束
curl_close($curl_xueji);
*/
//获取成绩
session_start();
$curl_allscore = curl_init();
$url_allscore = 'http://211.82.47.6/gradeLnAllAction.do?type=ln&oper=qbinfo&lnxndm=2016-2017学年秋(两学期)#2018-2019%E5%AD%A6%E5%B9%B4%E7%A7%8B(%E4%B8%A4%E5%AD%A6%E6%9C%9F)';
$cookie_jar = $cookie_jar;
$ip = $ip;
curl_setopt($curl_allscore,CURLOPT_URL,$url_allscore);
//curl_setopt($curl_allscore, CURLOPT_HTTPHEADER, $ip);  //构造IP 
curl_setopt($curl_allscore,CURLOPT_COOKIEFILE,$cookie_jar);
curl_setopt($curl_allscore,CURLOPT_RETURNTRANSFER,1);
$content_allscore = curl_exec($curl_allscore);
$content_allscore = iconv("gb2312", "utf-8",$content_allscore);
curl_close($curl_allscore);
$table = $content_allscore;
//echo $table;

preg_match_all('/<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">([\s\S]*?) <\/table>/',$table,$score); 
$zero = $score[20][0];
function get_td_array($table){
    $table = preg_replace("/&nbsp/", "", $table);
    $table = preg_replace("/;/", "", $table);
    $table = preg_replace("/ /", "", $table);
    $table = preg_replace("'<table[^>]*?>'si", "", $table);

    $table = preg_replace("'<tr[^>]*?>'si", "", $table);
    $table = preg_replace("'<td[^>]*?>'si", "", $table);

    $table = str_replace("</tr>", "{tr}", $table);
    $table = str_replace("</td>", "{td}", $table);

    $table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);
    $table = preg_replace("'([\r\n])[\s]+'", "", $table);
    $table = str_replace(" ", "", $table);
    $table = explode('{tr}', $table);
    array_pop($table);
    foreach ($table as $key => $tr) {
            $td = explode('{td}', $tr);
            array_pop($td);
            $td_array[] = $td;
            //print_r($td);
            //echo '</br>';
        
	}
    return $td_array;
}
$zero = get_td_array($zero);

//echo $zero;
$zero = json_encode($zero);
//echo $zero;
$allscore = $zero;
$openid = 'sadjAk123132D131';
$first = date('Y-m-d h:i:s', time());
$last = date('Y-m-d h:i:s', time());
$host = 'localhost:3306';
$username = 'btwh';
$password = 'btwh';
$dbname = 'btwh';
$mysqli = new mysqli($host,$username,$password,$dbname);
if(!$mysqli){
    //echo 'false';
}else{
    //echo 'success';
    $query = "INSERT INTO allscore(openid,allscore,first,last) VALUES(?,?,?,?)";
    $stmt =  $mysqli->prepare($query);
    $stmt->bind_param('ssss',$openid,$allscore,$first,$last);
    $openid = $openid;
    $allscore = $allscore;
    $first = $first;
    $last = $last;
    $stmt->execute();
    $stmt->close();
    $mysqli->close();
}

/*
echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';

function get_td_array($table){
    $table = preg_replace("/&nbsp/", "", $table);
    $table = preg_replace("/;/", "", $table);
    $table = preg_replace("/ /", "", $table);
    $table = preg_replace("'<table[^>]*?>'si", "", $table);

    $table = preg_replace("'<tr[^>]*?>'si", "", $table);
    $table = preg_replace("'<td[^>]*?>'si", "", $table);

    $table = str_replace("</tr>", "{tr}", $table);
    $table = str_replace("</td>", "{td}", $table);

    $table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);
    $table = preg_replace("'([\r\n])[\s]+'", "", $table);
    $table = str_replace(" ", "", $table);
    $table = explode('{tr}', $table);
    array_pop($table);
    foreach ($table as $key => $tr) {
            $td = explode('{td}', $tr);
            array_pop($td);
            $td_array[] = $td;
            //print_r($td);
            //echo '</br>';
        
	}
    return $td_array;
}
$score = get_td_array($table);
//print_r($score);
/*
//正则全部成绩界面
$html = $content_allscore;
preg_match_all('/<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">([\s\S]*?) <\/table>/',$html,$score); 

//大一第一学期
$ezro = $score[0][0];

//大一第二学期
$one = $score[0][1];

//大二第一学期
$two = $score[0][2];

//大二第二学期
$three = $score[0][3];

//大三第一学期
$four = $score[0][4];

//大三第二学期
$five = $score[0][5];

//大四第一学期
$six = $score[0][6];

//大四第二学期
$seven = $score[0][7];

//大五第一学期
$eight = $score[0][8];

//大五第二学期
$nine = $score[0][9];

$table = $five;

function get_td_array($table){
    $table = preg_replace("/&nbsp/", "", $table);
    $table = preg_replace("/;/", "", $table);
    $table = preg_replace("/ /", "", $table);
    $table = preg_replace("'<table[^>]*?>'si", "", $table);

    $table = preg_replace("'<tr[^>]*?>'si", "", $table);
    $table = preg_replace("'<td[^>]*?>'si", "", $table);

    $table = str_replace("</tr>", "{tr}", $table);
    $table = str_replace("</td>", "{td}", $table);

    $table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);
    $table = preg_replace("'([\r\n])[\s]+'", "", $table);
    $table = str_replace(" ", "", $table);
    $table = explode('{tr}', $table);
    array_pop($table);
    foreach ($table as $key => $tr) {
            $td = explode('{td}', $tr);
            array_pop($td);
            $td_array[] = $td;
            //print_r($td);
            //echo '</br>';
        
	}
    return $td_array;
}
$score = get_td_array($table);
//print_r($score);
$five = json_encode($score);
echo $five;

//将成绩储存到数据库
$openid = 'sadjAk123132D131';
$five = $five;
$first = date('Y-m-d h:i:s', time());
$last = date('Y-m-d h:i:s', time());
$host = 'localhost:3306';
$username = 'btwh';
$password = 'btwh';
$dbname = 'btwh';
$mysqli = new mysqli($host,$username,$password,$dbname);
if(!$mysqli){
    //echo 'The connection is false,please test again or wait a time!';
    $query = "INSERT INTO score(openid,zero,one,two,three,four,five,six,seven,eight,nine,first,last) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmt =  $mysqli->prepare($query);
    $stmt->bind_param('ssss',$openid,$zero,$one,$two,$three,$four,$five,$six,$seven,$eight,$nine,$first,$last);
    $openid = $openid;
    $zero = $zero;
    $one = $one;
    $two = $two;
    $three = $three;
    $four = $four;
    $five = $five;
    $six = $six;
    $seven = $seven;
    $eight = $eight;
    $nine = $nine;
    $first = $first;
    $last = $last;
    $stmt->execute();
    $stmt->close();
    $mysqli->close();
}
/*
echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';

$html = $content_allscore;
//echo $html;
echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';

preg_match_all('/<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">([\s\S]*?) <\/table>/',$html,$score); 
//$a = $score[0][0];
//echo $a;
//下方判断有几个学期
for($a=0;$a<10&&$score[0][$a]!='';$a++){
    
}
$a = $a-1;

//echo $a;
//大一第一学期
$ezro = $score[0][0];

//大一第二学期
$one = $score[0][1];

//大二第一学期
$two = $score[0][2];

//大二第二学期
$three = $score[0][3];

//大三第一学期
$four = $score[0][4];

//大三第二学期
$five = $score[0][5];

//大四第一学期
$six = $score[0][6];

//大四第二学期
$seven = $score[0][7];

//大五第一学期
$eight = $score[0][8];

//大五第二学期
$nine = $score[0][9];

$table = $five;
echo $table;
echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';
/*
preg_match_all('/<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">([\s\S]*?) <\/table>/',$nowscore,$score);
$table = $score[0][0];
echo $table;
*/
/*
function get_td_array($table){
    $table = preg_replace("/&nbsp/", "", $table);
    $table = preg_replace("/;/", "", $table);
    $table = preg_replace("/ /", "", $table);
    $table = preg_replace("'<table[^>]*?>'si", "", $table);

    $table = preg_replace("'<tr[^>]*?>'si", "", $table);
    $table = preg_replace("'<td[^>]*?>'si", "", $table);

    $table = str_replace("</tr>", "{tr}", $table);
    $table = str_replace("</td>", "{td}", $table);

    $table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);
    $table = preg_replace("'([\r\n])[\s]+'", "", $table);
    $table = str_replace(" ", "", $table);
    $table = explode('{tr}', $table);
    array_pop($table);
    foreach ($table as $key => $tr) {
            $td = explode('{td}', $tr);
            array_pop($td);
            $td_array[] = $td;
            //print_r($td);
            //echo '</br>';
        
	}
    return $td_array;
}
$score = get_td_array($table);
print_r($score);
echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';
$staff_serialize = serialize($score);
echo $staff_serialize;
echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';
$staff_json = json_encode($score);
echo $staff_json;





echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';
echo "~~~~~结尾线~~~~~~~~~~~";
echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';
*/

?>