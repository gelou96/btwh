<?php
$openid = 'sadjAk123132D131';
/*
$host = 'localhost:3306';
$username = 'btwh';
$password = 'btwh';
$dbname = 'btwh';
$mysqli = new mysqli($host,$username,$password,$dbname);
if(!$mysqli){
    
}else{
    $openid = $openid;
    $mysqli->query("set names utf8" ); 
    $result = $mysqli->query ("SELECT allscore FROM allscore WHERE openid='$openid'");
     while ( list ( $allscore ) = $result->fetch_row() ) {
         $score = $allscore;
     }
    $result->close (); // 关闭结果集
    $mysqli->close ();
}
echo $score;
echo '</br>';
echo '~~~~~~~~~~~~~~';
echo '</br>';
$staff_dejson = json_decode($score, true);
print_r($staff_dejson);
*/

function randIP(){
       $ip_long = array(
           array('607649792', '608174079'), //36.56.0.0-36.63.255.255
           array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
           array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
           array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
           array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
           array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
           array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
           array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
           array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
           array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
       );
       $rand_key = mt_rand(0, 9);
       $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
       $headers['CLIENT-IP'] = $ip; 
       $headers['X-FORWARDED-FOR'] = $ip; 

       $headerArr = array(); 
       foreach( $headers as $n => $v ) { 
           $headerArr[] = $n .':' . $v;  
       }
       return $headerArr;    
   }
   
$ip = randIP();
print_r($ip);
echo '</br>';
echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~";
echo '</br>';
$userzjh = '160807051237'; 
$usermm ='143913'; 
$userzjh = '190807051136';
$usermm = '020514';
$openid = 'asdasjsadhkj1dsa1das2';
$request = "mm=$usermm&zjh=$userzjh";
$cookie_jar = tempnam('./tmp','cookie'); //cookie储存位置
//开始模拟登录
$url_login = "http://211.82.47.6/loginAction.do";
$curl_login = curl_init(); //初始化，获得curl句柄
curl_setopt($curl_login,CURLOPT_URL,$url_login); 
curl_setopt($curl_login, CURLOPT_HTTPHEADER, $ip);  //构造IP 
curl_setopt($curl_login, CURLOPT_POST, 1); //使用post传输数据
curl_setopt($curl_login, CURLOPT_POSTFIELDS, $request); //传递数据
curl_setopt($curl_login, CURLOPT_COOKIEJAR, $cookie_jar); //把返回来的cookie信息保存在$cookie_jar文件中
curl_setopt($curl_login, CURLOPT_RETURNTRANSFER, 1); //设定返回的数据是否自动显示
curl_setopt($curl_login, CURLOPT_HEADER, false); //设定是否显示头信息
$content_login = curl_exec($curl_login); 
$content_login = preg_replace("'<[/!]*?[^<>]*?>'si","",$content_login);//去除html标记
$content_login = iconv("gb2312", "utf-8",$content_login);
//echo $content_login;
curl_close($curl_login);

session_start();
$ip = $ip;
$curl_table = curl_init();
$url_table = 'http://211.82.47.6/xkAction.do?actionType=6'; //(2019.1.31 需在此处换个链接)
curl_setopt($curl_table,CURLOPT_URL,$url_table);
curl_setopt($curl_table, CURLOPT_HTTPHEADER, $ip);  //构造IP 
curl_setopt($curl_table,CURLOPT_COOKIEFILE,$cookie_jar);
curl_setopt($curl_table,CURLOPT_RETURNTRANSFER,1);
$content_table = curl_exec($curl_table);
$content_table = iconv("gb2312", "utf-8",$content_table);
curl_close($curl_table );
//echo $content_table;
/*
function get_td_array($table){
    $table = $table;
    preg_match_all('/<table width="100%" border="0" cellpadding="0" cellspacing="0" class="titleTop2">([\s\S]*?) <\/table>/',$table,$kebiao); //去掉table标签，然后/table就没用了
    $table = $kebiao[0][0];
    $table = preg_replace("/&nbsp/", "", $table);

    $table = preg_replace("'<table[^>]*?>'si", "", $table);

    $table = preg_replace("'<tr[^>]*?>'si", "", $table);
    $table = preg_replace("'<td[^>]*?>'si", "", $table);

    $table = str_replace("</tr>", "{tr}", $table);
    $table = str_replace("</td>", "{td}", $table);

    $table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);
    $table = preg_replace("'([\r\n])[\s]+'", "", $table);
    $table = preg_replace("/;/", "", $table);
    $table = str_replace(" ", "", $table);
    $table = explode('{tr}', $table);
    array_pop($table);

    foreach ($table as $key => $tr) {
            $td = explode('{td}', $tr);
            array_pop($td);
            $td_array[] = $td;
            //print_r($td);
            //echo '</br>';
    }
    return $td_array;
    
}

$table = $content_table;
$table = get_td_array($table);
//print_r($table);

$openid = 'asdasjsadhkj1dsa1das2';
$kebiao = json_encode($table);
//echo $kebiao;

$first = date('Y-m-d h:i:s', time());
$last = date('Y-m-d h:i:s', time());
//开始储存到数据库
$host = 'localhost:3306';
$username = 'btwh';
$password = 'btwh';
$dbname = 'btwh';
$mysqli = new mysqli($host,$username,$password,$dbname);
if(!$mysqli){
    //echo 'false';
}else{
    //echo 'success';
    $query = "INSERT INTO kebiao(openid,kebiao,first,last) VALUES(?,?,?,?)";
    $stmt =  $mysqli->prepare($query);
    $stmt -> bind_param('ssss',$openid,$kebiao,$first,$last);
    $openid = $openid;
    $kebiao = $kebiao;
    $first = $first;
    $last = $last;
    $stmt->execute();
    $stmt->close();
    $mysqli->close();
}

*/




echo '</br>';
echo '~~~~~~123~~~~~~~~';
echo '</br>';
include('table.php');
$openid = $openid;
$table = $content_table;
$content = table($openid,$table);
//print_r($content);
/*
echo '</br>';
echo '~~~~~~~~456~~~~~~';
echo '</br>';
$content = json_encode($content);

//echo $content;
echo '</br>';
echo '~~~~~~~~789~~~~~~';
echo '</br>';
$staff_dejson = json_decode($content, true);  // JSON解码成数组
print_r($staff_dejson);




/*
//获取成绩
session_start();
$curl_allscore = curl_init();
$url_allscore = 'http://211.82.47.6/gradeLnAllAction.do?type=ln&oper=qbinfo&lnxndm=2016-2017学年秋(两学期)#2018-2019%E5%AD%A6%E5%B9%B4%E7%A7%8B(%E4%B8%A4%E5%AD%A6%E6%9C%9F)';
$cookie_jar = $cookie_jar;
$ip = $ip;
curl_setopt($curl_allscore,CURLOPT_URL,$url_allscore);
//curl_setopt($curl_allscore, CURLOPT_HTTPHEADER, $ip);  //构造IP 
curl_setopt($curl_allscore,CURLOPT_COOKIEFILE,$cookie_jar);
curl_setopt($curl_allscore,CURLOPT_RETURNTRANSFER,1);
$content_allscore = curl_exec($curl_allscore);
$content_allscore = iconv("gb2312", "utf-8",$content_allscore);
curl_close($curl_allscore);
$table = $content_allscore;
include('class.php');
$openid = $openid;
$allscore = $table;
class_allscore($openid,$allscore);
*/
?>