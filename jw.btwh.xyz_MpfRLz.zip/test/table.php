<?php
/*用途：获取课表并储存
  时间：2020.01.02
  阁楼~么么哒
*/

function get_td_array($table){
    $table = $table;
    preg_match_all('/<table width="100%" border="0" cellpadding="0" cellspacing="0" class="titleTop2">([\s\S]*?) <\/table>/',$table,$kebiao); //去掉table标签，然后/table就没用了
    $table = $kebiao[0][0];
    $table = preg_replace("/&nbsp/", "", $table);

    $table = preg_replace("'<table[^>]*?>'si", "", $table);

    $table = preg_replace("'<tr[^>]*?>'si", "", $table);
    $table = preg_replace("'<td[^>]*?>'si", "", $table);

    $table = str_replace("</tr>", "{tr}", $table);
    $table = str_replace("</td>", "{td}", $table);

    $table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);
    $table = preg_replace("'([\r\n])[\s]+'", "", $table);
    $table = preg_replace("/;/", "", $table);
    $table = str_replace(" ", "", $table);
    $table = explode('{tr}', $table);
    array_pop($table);

    foreach ($table as $key => $tr) {
            $td = explode('{td}', $tr);
            array_pop($td);
            $td_array[] = $td;
            //print_r($td);
            //echo '</br>';
    }
    return $td_array;
    
}


function table($openid,$table){
    $openid = $openid;
    $table = $table;
    $table = get_td_array($table);
    $kebiao = json_encode($table);
    $first = date('Y-m-d h:i:s', time());
    $last = date('Y-m-d h:i:s', time());
    
    //开始储存到数据库
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if(!$mysqli){
        //echo 'false';
    }else{
        //echo 'success';
        $query = "INSERT INTO kebiao(openid,kebiao,first,last) VALUES(?,?,?,?)";
        $stmt =  $mysqli->prepare($query);
        $stmt -> bind_param('ssss',$openid,$kebiao,$first,$last);
        $openid = $openid;
        $kebiao = $kebiao;
        $first = $first;
        $last = $last;
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
    
}
?>