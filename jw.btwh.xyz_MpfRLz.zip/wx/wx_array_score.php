<?php
function wx_array_score($openid){
    $open = $openid;
    //链接数据库
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if (mysqli_connect_errno ()){
        $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
    }else{
        $mysqli->query("set names utf8" ); // 设置结果的字符集
        $result = $mysqli->query ( "SELECT openid FROM bindmessage WHERE openid='$open'" );
        if ( !list ( $openid ) = $result->fetch_row() ){
            $message =  '<a href="http://jw.btwh.xyz/web/login.php?openid='.$open.'">点我进行绑定教务</a>';
            $result->close (); // 关闭结果集
            $mysqli->close (); 
        }else{
            $openid = $open;
            $mysqli->query("set names utf8" ); // 设置结果的字符集
            $result = $mysqli->query ("SELECT xh,mm FROM bindmessage WHERE openid='$openid'");
            while ( list ( $xh,$mm ) = $result->fetch_row() ) { // 从结果集中遍历每条数据
                $zh = $xh;
                $mima = $mm;
            }
            $result->close (); // 关闭结果集
            $mysqli->close ();
            $userzjh = preg_replace("'([\r\n])[\s]+'", "", $zh);
            $usermm = preg_replace("'([\r\n])[\s]+'", "", $mima);
            
            //判断此学生大几
			if($userzjh>140000000000&&$userzjh<150000000000){
				$gl = 10;
			}else if($userzjh>150000000000&&$userzjh<160000000000){
				$gl = 8;
			}else if($userzjh>160000000000&&$userzjh<170000000000){
				$gl = 6;
			}else if($userzjh>170000000000&&$userzjh<180000000000){
				$gl = 4;
			}else if($userzjh>180000000000&&$userzjh<190000000000){
				$gl = 2;
			}else if($userzjh>190000000000&&$userzjh<200000000000){
				$gl = 0;
			}
			$gl = $gl;
			
			$request = "mm=$usermm&zjh=$userzjh";
            $cookie_jar = tempnam('./tmp','cookie'); //cookie储存位置

      
            function randIP(){
                $ip_long = array(
                   array('607649792', '608174079'), //36.56.0.0-36.63.255.255
                   array('1038614528', '1039007743'), //61.232.0.0-61.237.255.255
                   array('1783627776', '1784676351'), //106.80.0.0-106.95.255.255
                   array('2035023872', '2035154943'), //121.76.0.0-121.77.255.255
                   array('2078801920', '2079064063'), //123.232.0.0-123.235.255.255
                   array('-1950089216', '-1948778497'), //139.196.0.0-139.215.255.255
                   array('-1425539072', '-1425014785'), //171.8.0.0-171.15.255.255
                   array('-1236271104', '-1235419137'), //182.80.0.0-182.92.255.255
                   array('-770113536', '-768606209'), //210.25.0.0-210.47.255.255
                   array('-569376768', '-564133889'), //222.16.0.0-222.95.255.255
                );
                $rand_key = mt_rand(0, 9);
                $ip= long2ip(mt_rand($ip_long[$rand_key][0], $ip_long[$rand_key][1]));
                $headers['CLIENT-IP'] = $ip; 
                $headers['X-FORWARDED-FOR'] = $ip; 

                $headerArr = array(); 
                foreach( $headers as $n => $v ) { 
                   $headerArr[] = $n .':' . $v;  
                }
                return $headerArr;    
            }
   
            $ip = randIP();

            $curl_login = curl_init(); //初始化，获得curl句柄
			//登录
			curl_setopt($curl_login,CURLOPT_URL,'http://211.82.47.6/loginAction.do'); //要抓取的页面url
			curl_setopt($curl_login, CURLOPT_HTTPHEADER, $ip);  //构造IP 
			curl_setopt($curl_login, CURLOPT_POST, 1); //使用post传输数据
			curl_setopt($curl_login, CURLOPT_POSTFIELDS, $request); //传递数据
			curl_setopt($curl_login, CURLOPT_COOKIEJAR, $cookie_jar); //把返回来的cookie信息保存在$cookie_jar文件中
			curl_setopt($curl_login, CURLOPT_RETURNTRANSFER, 1); //设定返回的数据是否自动显示
			curl_setopt($curl_login, CURLOPT_HEADER, false); //设定是否显示头信息
			$content_login = curl_exec($curl_login); 
			$content_login = preg_replace("'<[/!]*?[^<>]*?>'si","",$content_login);//去除html标记
			$content_login = iconv("gb2312", "utf-8",$content_login);
			curl_close($curl_login);
			
			//所有成绩
			$curl_allscore = curl_init(); //重新建立一个会话
			$url_allscore = 'http://211.82.47.6/gradeLnAllAction.do?type=ln&oper=qbinfo&lnxndm=2016-2017学年秋(两学期)#2018-2019%E5%AD%A6%E5%B9%B4%E7%A7%8B(%E4%B8%A4%E5%AD%A6%E6%9C%9F)'; //(2019.1.31 需在此处换个链接)
			$cookie_jar = $cookie_jar;
			$ip = $ip;
			curl_setopt($curl_allscore,CURLOPT_URL,$url_allscore);
			curl_setopt($curl_allscore, CURLOPT_HTTPHEADER, $ip);  //构造IP 
			curl_setopt($curl_allscore,CURLOPT_COOKIEFILE,$cookie_jar);
			curl_setopt($curl_allscore,CURLOPT_RETURNTRANSFER,1);
			$content_allscore = curl_exec($curl_allscore);
			$content_allscore = iconv("gb2312", "utf-8",$content_allscore);
			//echo $content_allscore;
			curl_close($curl_allscore);
			
			$html = $content_allscore;
			preg_match_all('/<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">([\s\S]*?) <\/table>/',$html,$kebiao); 
			$url_score = $kebiao[0][$gl];
			
			preg_match_all('/<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">([\s\S]*?) <\/table>/',$url_score,$score);
			$table = $score[0][0];
			//开始正则分析
			$table = preg_replace("/&nbsp/", "", $table); //去掉空格
			$table = preg_replace("'<table[^>]*?>'si", "", $table);
			$table = preg_replace("'<tr[^>]*?>'si", "", $table);
			$table = preg_replace("'<td[^>]*?>'si", "", $table);
			$table = str_replace("</tr>", "{tr}", $table);
			$table = str_replace("</td>", "{td}", $table);
			$table = preg_replace("'<[\/\!]*?[^<>]*?>'si", "", $table);
			$table = preg_replace("'([\r\n])[\s]+'", "", $table);
			$table = str_replace(" ", "", $table);
			$table = explode('{tr}', $table);
			array_pop($table);
			
			foreach ($table as $key => $tr){
				$td = explode('{td}', $tr);
				array_pop($td);
				$td_array[] = $td;
			}
			
			//开始输出成绩
			$br = "\n";
			$fy = "   ";
			
			//计算两个时间差的方法 
			$startdate="2019-09-02 00:00:00";
			$enddate=date("y-m-d h:i:s");
			$date=floor((strtotime($enddate)-strtotime($startdate))/86400);
			//echo $date."天<br>";
			$b = $date%7;
			$a = $date-$b;
			$a = $a/7;
			
			$year = "考试周啦！加油复习么么哒~"."/:,@-D".$br."此系统即时更新哦！"."/:,@f".$br.$br;
			$table_all = '<a href="http://jw.btwh.xyz/web/Showscore.php?openid='.$openid.'">点我查看所有成绩</a>';
			$table_all = $br.$table_all.$br.$br.'<a href="http://jw.btwh.xyz/web/function?openid='.$openid.'">所有成绩（未做完，暂不上线）</a>'/*.$br.$br.'<a href="https://mp.weixin.qq.com/s/VabR1N-lX-xQfJlaDlpxlw">点一下就行~</a>'*/.$br.$br.'<a href="https://jq.qq.com/?_wv=1027&k=579KBZj">点我进群</a>'.' 811827677';'<a href="weixin://bizmsgmenu?msgmenuid=355&msgmenucontent=阁楼">广告位|招商</a>';
			$data_score = '2019-2020学年秋(第一学期)';
			$message =$td_array[6][2].$fy.$td_array[6][6].$br.$td_array[7][2].$fy.$td_array[7][6].$br.$td_array[8][2].$fy.$td_array[8][6].$br.$td_array[9][2].$fy.$td_array[9][6].$br.$td_array[10][2].$fy.$td_array[10][6].$br.$td_array[11][2].$fy.$td_array[11][6].$br.$td_array[12][2].$fy.$td_array[12][6].$br.$td_array[13][2].$fy.$td_array[13][6].$br.$td_array[14][2].$fy.$td_array[14][6].$br.$td_array[15][2].$fy.$td_array[15][6].$br.$td_array[16][2].$fy.$td_array[16][6].$br.$td_array[17][2].$fy.$td_array[17][6].$br.$td_array[18][2].$fy.$td_array[18][6].$br.$td_array[19][2].$fy.$td_array[19][6].$br.$td_array[20][2].$fy.$td_array[20][6].$br.$td_array[21][2].$fy.$td_array[21][6].$br.$td_array[22][2].$fy.$td_array[22][6].$br.$td_array[23][2].$fy.$td_array[23][6];
			$message = preg_replace("/;/", "", $message);
			$message = preg_replace("'([\r\n])[\s]+'", "", $message);
			$message = $year.$data_score.$br.$message.$br.$table_all;       
        }
        $message = $message;
    }
    $message = $message;
    return $message;
    
}
?>