<?php
//此为文件有坑，即openid的重复，需换不同的参数！
//时间：2020.01.05

function bind($openid){
    $open = $openid;
    //链接数据库
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if (mysqli_connect_errno ()){
        $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
    }else{
        $mysqli->query("set names utf8" ); // 设置结果的字符集
        $result = $mysqli->query ( "SELECT openid FROM bindmessage WHERE openid='$open'" );
        if ( !list ( $openid ) = $result->fetch_row() ){
            $message =  '<a href="http://jw.btwh.xyz/web/login.php?openid='.$open.'">点我进行绑定教务</a>';
        }else{
            $message = '<a href="http://jw.btwh.xyz/web/function.php?openid='.$open.'">你已经绑定过啦,点我进入功能界面！</a>';
        }
    }  
    
    $result->close (); // 关闭结果集
    $mysqli->close (); 
    $bind = $message;
    return $bind;
}
?>