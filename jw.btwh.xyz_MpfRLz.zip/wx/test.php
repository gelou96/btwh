<?php
$open = 'oNAt2wG51eCgRfXziwd0DD3xf0SE';
    $host = 'localhost:3306';
    $username = 'btwh';
    $password = 'btwh';
    $dbname = 'btwh';
    $mysqli = new mysqli($host,$username,$password,$dbname);
    if (mysqli_connect_errno ()){
        $message = "抱歉，系统出错啦，请稍后再试或者联系微信：18235273200";
    }else{
        $open = $open;
        $mysqli->query("set names utf8" ); // 设置结果的字符集
        $result = $mysqli->query ( "SELECT openid FROM kebiao WHERE openid='$open'" );
        if ( !list ( $openid ) = $result->fetch_row() ){
            $message =  '<a href="http://jw.btwh.xyz/web/login.php?openid='.$open.'">点我重新绑定教务|新系统|望理解</a>';
            $result->close (); 
            $mysqli->close ();
        }else{
            $openid = $open;
            $mysqli->query("set names utf8" ); // 设置结果的字符集
            $result = $mysqli->query ("SELECT kebiao FROM kebiao WHERE openid='$openid'");
             while ( list ( $kebiao ) = $result->fetch_row() ) { // 从结果集中遍历每条数据
                $kb = $kebiao;
            }
            $result->close (); // 关闭结果集
            $mysqli->close ();
            $kb = $kb;
        }
        $td_array = json_decode($kb, true);
        //周一
        $td_array[0][0]=$td_array[1][0]; //上午
        $td_array[0][1]=$td_array[1][2]; //第一节课
        $td_array[0][2]=$td_array[3][1]; //第二节课
        $td_array[0][3]=$td_array[6][0]; //下午
        $td_array[0][4]=$td_array[6][2]; //第一节课
        $td_array[0][5]=$td_array[8][1]; //第二节课
        $td_array[0][6]=$td_array[11][0]; //晚上
        $td_array[0][7]=$td_array[11][2]; //第一节课

        //周日
        $td_array[6][1]=$td_array[1][8]; //周日第一节课

        //周六
        $td_array[5][1]=$td_array[1][7]; //周六第一节课

        //周五
        $td_array[4][1]=$td_array[1][6]; //周五第一节课

        //周四
        $td_array[3][1]=$td_array[1][5]; //周四第一节课

        //周三
        $td_array[2][1]=$td_array[1][4]; //周三第一节课

        //周二
        $td_array[1][0]=$td_array[0][0]; //上午
        $td_array[1][1]=$td_array[1][3]; //第一节课
        $td_array[1][2]=$td_array[3][2]; //第二节课
        $td_array[1][3]=$td_array[0][3]; //下午
        $td_array[1][4]=$td_array[6][3]; //第一节课
        $td_array[1][5]=$td_array[8][2]; //第二节课
        $td_array[1][6]=$td_array[0][6]; //晚上
        $td_array[1][7]=$td_array[11][3]; //第一节课

        //周三
        $td_array[2][0]=$td_array[0][0]; //上午

        $td_array[2][2]=$td_array[3][3]; //第二节课
        $td_array[2][3]=$td_array[0][3]; //下午
        $td_array[2][4]=$td_array[6][4]; //第一节课
        $td_array[2][5]=$td_array[8][3]; //第二节课
        $td_array[2][6]=$td_array[0][6]; //晚上
        $td_array[2][7]=$td_array[11][4]; //第一节课

        //周日
        $td_array[6][2]=$td_array[3][7]; //周日第二节课

        //周六
        $td_array[5][2]=$td_array[3][6]; //周六第二节课

        //周五
        $td_array[4][2]=$td_array[3][5]; //周五第二节课

        //周四
        $td_array[3][0]=$td_array[0][0]; //上午

        $td_array[3][2]=$td_array[3][4]; //第二节课
        $td_array[3][3]=$td_array[0][3]; //下午
        $td_array[3][4]=$td_array[6][5]; //第一节课
        $td_array[3][5]=$td_array[8][4]; //第二节课
        $td_array[3][6]=$td_array[0][6]; //晚上
        $td_array[3][7]=$td_array[11][5]; //第一节课

        //周五
        $td_array[4][0]=$td_array[0][0]; //上午


        $td_array[4][3]=$td_array[0][3]; //下午
        $td_array[4][4]=$td_array[6][6]; //第一节课
        $td_array[4][5]=$td_array[8][5]; //第二节课
        $td_array[4][6]=$td_array[0][6]; //晚上
        $td_array[4][7]=$td_array[11][6]; //第一节课

        //周六
        $td_array[5][0]=$td_array[0][0]; //上午


        $td_array[5][3]=$td_array[0][3]; //下午
        $td_array[5][4]=$td_array[6][7]; //第一节课
        $td_array[5][5]=$td_array[8][6]; //第二节课
        $td_array[5][6]=$td_array[0][6]; //晚上
        $td_array[5][7]=$td_array[11][7]; //第一节课

        //周日
        $td_array[6][0]=$td_array[0][0]; //上午


        $td_array[6][3]=$td_array[0][3]; //下午
        $td_array[6][4]=$td_array[6][8]; //第一节课
        $td_array[6][5]=$td_array[8][7]; //第二节课
        $td_array[6][6]=$td_array[0][6]; //晚上
        $td_array[6][7]=$td_array[11][8]; //第一节课

        $data = date("l");//星期几
        //echo $data;
        $br = "\n";

        //计算两个时间差的方法 
        $startdate="2019-09-01 00:00:00";
        $enddate=date("y-m-d h:i:s");
        $date=floor((strtotime($enddate)-strtotime($startdate))/86400);
        echo $date."天<br>";
        $b = $date%7;
        $a = $date-$b;
        $a = $a/7+1;

        $year = "这周已经第" .$a."周啦！"."/:,@-D".$br."2019-2020学年第一学期课表".$br.$br.$br;
        $table_all = '<a href="http://jw.btwh.xyz/web/function.php?openid='.$openid.'">点我查看所有课表</a>';
        $table_all = $br.$table_all.$br.$br.'<a href="weixin://bizmsgmenu?msgmenuid=112&msgmenucontent=通知">教务处最新通知</a>'.$br.$br.'<a href="http://dtxtcm.cn/yhquan.php">塘塘养家糊口~~</a>';/*'<a href="https://mp.weixin.qq.com/s/lv28LmwUIJZDcU0rTT8k3Q">她，毕业两年为何。。|广告</a>';/*'<a href="https://mp.weixin.qq.com/s/hGz-XkhA8heLtCJmyiIAMg">奥宇二楼|满10减5</a>';*/
        $br = "\n";
        $shangwu = '   ~~~~~      ';
        $shangwu1 = '      ~~~~~';

        $xiawu = '   ~~~~~      ';
        $xiawu1 = '      ~~~~~';

        $wanshang =  '   ~~~~~      ';
        $wanshang1 = '      ~~~~~';

        //$input = $td_array[0][0].$br.$td_array[0][1].$br.$td_array[0][2].$br.$td_array[0][2].$br.$td_array[0][3].$br.$td_array[0][4].$br.$td_array[0][5].$br.$td_array[0][6].$br.$td_array[0][7];

        //echo $input;

        $data = 'Tuesday';
        switch($data){
            case 'Monday':
            $message = $year.$shangwu.$td_array[0][0].$shangwu1.$br.$br.$td_array[0][1].$br.$td_array[0][2].$br.$br.$xiawu.$td_array[0][3].$xiawu1.$br.$br.$td_array[0][4].$br.$td_array[0][5].$br.$br.$wanshang.$td_array[0][6].$wanshang1.$br.$br.$td_array[0][7].$br.$table_all;
            break;

            case 'Tuesday':
            $message = $year.$shangwu.$td_array[1][0].$shangwu1.$br.$br.$td_array[1][1].$br.$td_array[1][2].$br.$br.$xiawu.$td_array[1][3].$xiawu1.$br.$br.$td_array[1][4].$br.$td_array[1][5].$br.$br.$wanshang.$td_array[1][6].$wanshang1.$br.$br.$td_array[1][7].$br.$table_all;
            break;

            case 'Wednesday':
            $message = $year.$shangwu.$td_array[2][0].$shangwu1.$br.$br.$td_array[2][1].$br.$td_array[2][2].$br.$br.$xiawu.$td_array[2][3].$xiawu1.$br.$br.$td_array[2][4].$br.$td_array[2][5].$br.$br.$wanshang.$td_array[2][6].$wanshang1.$br.$br.$td_array[2][7].$br.$table_all;
            break;

            case 'Thursday':
            $message = $year.$shangwu.$td_array[3][0].$shangwu1.$br.$br.$td_array[3][1].$br.$td_array[3][2].$br.$br.$xiawu.$td_array[3][3].$xiawu1.$br.$br.$td_array[3][4].$br.$td_array[3][5].$br.$br.$wanshang.$td_array[3][6].$wanshang1.$br.$br.$td_array[3][7].$br.$table_all;
            break;

            case 'Friday':
            $message = $year.$shangwu.$td_array[4][0].$shangwu1.$br.$br.$td_array[4][1].$br.$td_array[4][2].$br.$br.$xiawu.$td_array[4][3].$xiawu1.$br.$br.$td_array[4][4].$br.$td_array[4][5].$br.$br.$wanshang.$td_array[4][6].$wanshang1.$br.$br.$td_array[4][7].$br.$table_all;
            break;

            case 'Saturday':
            $message = $year.$shangwu.$td_array[5][0].$shangwu1.$br.$br.$td_array[5][1].$br.$td_array[5][2].$br.$br.$xiawu.$td_array[5][3].$xiawu1.$br.$br.$td_array[5][4].$br.$td_array[5][5].$br.$br.$wanshang.$td_array[5][6].$wanshang1.$br.$br.$td_array[5][7].$br.$table_all;
            break;

            case 'Sunday':
            $message = $year.$shangwu.$td_array[6][0].$shangwu1.$br.$br.$td_array[6][1].$br.$td_array[6][2].$br.$br.$xiawu.$td_array[6][3].$xiawu1.$br.$br.$td_array[6][4].$br.$td_array[6][5].$br.$br.$wanshang.$td_array[6][6].$wanshang1.$br.$br.$td_array[6][7].$br.$table_all;
            break;

            default:
            $message  = "系统出错了！";
            }
        
        
        $message = $message;
    }
    
    $message = $message;
    echo $message;
?>